package com.namelesscycle.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Outline;
import android.view.ViewOutlineProvider;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;
import android.content.res.AssetManager;
import com.chaquo.python.Python;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private static final String LOCAL_URL = "http://127.0.0.1:8765/";
    private static volatile boolean serverStarted = false;
    private WebView webView;
    private TextView loading;
    private FrameLayout splashView;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(36,24,18));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(36,24,18));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith(LOCAL_URL);
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith(LOCAL_URL)) hideSplash();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        splashView = new FrameLayout(this);
        splashView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(16,20,37),Color.rgb(29,26,40),Color.rgb(18,13,22)}));
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER);
        column.setPadding(dp(24), dp(20), dp(24), dp(20));
        ImageView hero = new ImageView(this);
        hero.setImageResource(com.namelesscycle.game.R.drawable.loading_hero);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setClipToOutline(true);
        hero.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(24));
            }
        });
        column.addView(hero, new LinearLayout.LayoutParams(dp(200),dp(200)));
        TextView title = new TextView(this);
        title.setText("無 名 輪 迴");
        title.setTextSize(29);
        title.setTextColor(Color.rgb(255,237,208));
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,dp(55));
        tp.topMargin=dp(14);
        column.addView(title,tp);
        loading = new TextView(this);
        loading.setText("正在開啟輪迴之門……");
        loading.setTextSize(14);
        loading.setGravity(Gravity.CENTER);
        loading.setTextColor(Color.rgb(220,208,224));
        column.addView(loading,new LinearLayout.LayoutParams(-1,dp(44)));
        ProgressBar progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(Color.rgb(226,198,155)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(198),dp(4));
        pp.gravity=Gravity.CENTER_HORIZONTAL;
        pp.topMargin=dp(10);
        column.addView(progress,pp);
        TextView hint = new TextView(this);
        hint.setText("✦  不同名字，同樣的靈魂  ✦");
        hint.setTextSize(11);
        hint.setTextColor(Color.rgb(170,166,191));
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));
        hp.topMargin=dp(6);
        column.addView(hint,hp);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        splashView.addView(column,cp);
        root.addView(splashView,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        if (!serverStarted) {
            synchronized (MainActivity.class) {
                if (!serverStarted) {
                    serverStarted = true;
                    new Thread(() -> {
                        try {
                            File dataRoot = new File(getFilesDir(), "game");
                            dataRoot.mkdirs();
                            File version = new File(dataRoot, ".assets_version_22");
                            if (!version.exists()) {
                                copyAssetFolder(getAssets(), "game", dataRoot);
                                version.createNewFile();
                            }
                            Python.getInstance().getModule("android_entry")
                                    .callAttr("start_server", dataRoot.getAbsolutePath());
                        } catch (Exception error) {
                            serverStarted = false;
                            runOnUiThread(() -> loading.setText("無法啟動遊戲：\n"+error.getMessage()));
                        }
                    }).start();
                }
            }
        }
        new Thread(() -> {
            for (int attempt=0;attempt<120;attempt++) {
                HttpURLConnection conn = null;
                try {
                    conn = (HttpURLConnection)new URL(LOCAL_URL+"api/state").openConnection();
                    conn.setConnectTimeout(500);
                    conn.setReadTimeout(500);
                    if (conn.getResponseCode()==200) {
                        runOnUiThread(() -> webView.loadUrl(LOCAL_URL));
                        return;
                    }
                } catch (Exception ignored) { }
                finally { if (conn!=null)conn.disconnect(); }
                try { Thread.sleep(250); } catch (InterruptedException ignored) { return; }
            }
            runOnUiThread(() -> loading.setText("遊戲啟動逾時，請重新開啟應用程式。"));
        }).start();
    }
    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density*value);
    }
    private void hideSplash() {
        if (splashView.getVisibility()!=View.VISIBLE) return;
        splashView.animate().alpha(0f).setDuration(330).withEndAction(() ->
                splashView.setVisibility(View.GONE)).start();
    }
    private static void copyAssetFolder(AssetManager assets, String assetPath, File output) throws Exception {
        String[] entries=assets.list(assetPath);
        if (entries==null) return;
        output.mkdirs();
        for (String entry: entries) {
            String name=assetPath+"/"+entry;
            String[] children=assets.list(name);
            File file=new File(output,entry);
            if (children!=null && children.length>0) copyAssetFolder(assets,name,file);
            else {
                try (InputStream in=assets.open(name);OutputStream out=new FileOutputStream(file)) {
                    byte[] buf=new byte[16384]; int n;
                    while ((n=in.read(buf))!=-1)out.write(buf,0,n);
                }
            }
        }
    }
    @Override protected void onPause() {
        webView.evaluateJavascript("if (typeof stopMusic === 'function') stopMusic();", null);
        webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        webView.onResume();
        webView.evaluateJavascript("if (typeof startMusic === 'function') startMusic();", null);
    }
    @Override protected void onDestroy() { webView.destroy();super.onDestroy(); }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
