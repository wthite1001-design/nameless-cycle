package com.namelesscycle.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;
import android.content.res.AssetManager;
import com.chaquo.python.Python;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private static final String LOCAL_URL = "http://127.0.0.1:8765/";
    private static volatile boolean serverStarted = false;
    private WebView webView;
    private TextView loading;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(36,24,18));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(36,24,18));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith(LOCAL_URL);
            }
            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        loading = new TextView(this);
        loading.setText("無名輪迴\n正在開啟輪迴之門……");
        loading.setTextSize(19);
        loading.setGravity(Gravity.CENTER);
        loading.setTextColor(Color.WHITE);
        loading.setBackgroundColor(Color.rgb(36,24,18));
        root.addView(loading, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        if (!serverStarted) {
            synchronized (MainActivity.class) {
                if (!serverStarted) {
                    serverStarted = true;
                    new Thread(() -> {
                        try {
                            File dataRoot = new File(getFilesDir(), "game");
                            dataRoot.mkdirs();
                            File version = new File(dataRoot, ".assets_version_2");
                            if (!version.exists()) {
                                copyAssetFolder(getAssets(), "game", dataRoot);
                                version.createNewFile();
                            }
                            Python.getInstance().getModule("android_entry")
                                    .callAttr("start_server", dataRoot.getAbsolutePath());
                        } catch (Exception error) {
                            serverStarted = false;
                            runOnUiThread(() -> loading.setText("無法啟動遊戲：\n"+error.getMessage()));
                        }
                    }).start();
                }
            }
        }
        new Thread(() -> {
            for (int attempt=0;attempt<120;attempt++) {
                HttpURLConnection conn = null;
                try {
                    conn = (HttpURLConnection)new URL(LOCAL_URL+"api/state").openConnection();
                    conn.setConnectTimeout(500);
                    conn.setReadTimeout(500);
                    if (conn.getResponseCode()==200) {
                        runOnUiThread(() -> webView.loadUrl(LOCAL_URL));
                        return;
                    }
                } catch (Exception ignored) { }
                finally { if (conn!=null)conn.disconnect(); }
                try { Thread.sleep(250); } catch (InterruptedException ignored) { return; }
            }
            runOnUiThread(() -> loading.setText("遊戲啟動逾時，請重新開啟應用程式。"));
        }).start();
    }
    private static void copyAssetFolder(AssetManager assets, String assetPath, File output) throws Exception {
        String[] entries=assets.list(assetPath);
        if (entries==null) return;
        output.mkdirs();
        for (String entry: entries) {
            String name=assetPath+"/"+entry;
            String[] children=assets.list(name);
            File file=new File(output,entry);
            if (children!=null && children.length>0) copyAssetFolder(assets,name,file);
            else {
                try (InputStream in=assets.open(name);OutputStream out=new FileOutputStream(file)) {
                    byte[] buf=new byte[16384]; int n;
                    while ((n=in.read(buf))!=-1)out.write(buf,0,n);
                }
            }
        }
    }
    @Override protected void onPause() { webView.onPause();super.onPause(); }
    @Override protected void onResume() { super.onResume();webView.onResume(); }
    @Override protected void onDestroy() { webView.destroy();super.onDestroy(); }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
