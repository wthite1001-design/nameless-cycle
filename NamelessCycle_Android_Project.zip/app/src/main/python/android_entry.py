"""Boot the original Python game on Android. All save files remain in app-private storage."""
import os

def start_server(root):
    os.environ['NML_BASE_DIR'] = root
    import game
    from http.server import ThreadingHTTPServer
    game.STATE = game.read_save()
    game.sync_legacy_codex()
    srv = ThreadingHTTPServer(('127.0.0.1', 8765), game.Handler)
    srv.serve_forever()
