"""《無名輪迴》角色、劇情、結局資料；可自行新增事件及角色。"""
from dataclasses import dataclass, field

CHARACTERS = {
    'yu': ('余魚', 'yu.jpg'), 'mao': ('懋貓', 'mao.jpg'),
    'boy': ('無名少年', 'boy.jpg'), 'girl': ('無名少女', 'girl.jpg'),
    'dealer': ('荷官', 'dealer.jpg'), 'reporter': ('記者', 'reporter.jpg'),
    'detective': ('男偵探', 'detective.jpg'), 'detective_f': ('女偵探', 'detective_f.jpg'),
    'researcher': ('研究員', 'researcher.jpg'), 'mercenary': ('傭兵', 'mercenary.jpg'),
    'guard': ('護衛', 'guard.jpg'), 'friend': ('青梅竹馬', 'friend.jpg'),
    'rival': ('宿敵', 'rival.jpg'), 'child': ('孩童', 'child.jpg'),
    'elder': ('老人', 'elder.jpg'), 'traveler': ('神秘旅人', 'traveler.jpg'),
    'other': ('另一位玩家', 'other.jpg'),
    'doctor_m': ('男醫生', 'doctor_m.jpg'),
}

# choice = (按鈕, 事件結果, {數值變化}, {因果旗標}, 是否立即死亡)
def C(label, result, effects=None, flags=None, die=False):
    return {'label': label, 'result': result, 'effects': effects or {}, 'flags': flags or {}, 'die': die}

def E(eid, who, title, story, left, right, min_age=18, max_age=100, min_life=1,
      min_year=2026, require=None, once=False, weight=1):
    return dict(id=eid, who=who, title=title, story=story, choices=[left,right],
                min_age=min_age, max_age=max_age, min_life=min_life, min_year=min_year,
                require=require or {}, once=once, weight=weight)

EVENTS = [
    E('friend_1','friend','未完成的約定','畢業的鐘聲響起，他把寫滿願望的紙條遞給你：「我們以後還會常見面吧？」',C('承諾保持聯絡','他笑著收好紙條，約定在多年後再見。',{'bonds':8,'friend':3},{'friend_promise':True}),C('順其自然','你們在夕陽裡道別，誰也沒有說再見。',{'bonds':-2}),max_age=28,once=True,weight=3),
    E('friend_2','friend','舊日的邀約','多年後，他邀請你去曾經一起散步的地方。「這次，別再臨時取消了。」',C('赴約','你們談到深夜，彷彿時光從未流逝。',{'bonds':7,'friend':3},{'friend_met':True}),C('婉拒','他說沒有關係，沉默卻比往常久。',{'bonds':-4,'friend':-2}),min_age=24,require={'friend_promise':True}),
    E('friend_3','friend','未寄出的信','一封寫著你名字的舊信被送到手中，字跡是你熟悉的那個人。',C('立即拆開','信裡寫著一句：「那一年，我其實喜歡你。」',{'bonds':5,'friend':5},{'friend_confession':True}),C('留待以後','你把信收進抽屜，心想往後總有時間。',{'bonds':-2},{'unopened_letter':True}),min_age=25),
    E('friend_4','friend','平凡的一日','他提議你暫時放下所有計畫，去吃一頓普通的晚餐。',C('陪他吃晚餐','沒有驚天動地的故事，但你記住了他的笑容。',{'health':3,'bonds':5,'friend':2}),C('繼續追尋答案','你說自己還有更重要的事，他點頭目送你走遠。',{'truth':3,'friend':-2}),min_age=26),
    E('friend_5','friend','重逢時刻','偶然的車站重逢，他問：「如果回到那一年，你會選擇留下嗎？」',C('回答會','你們重新寫下彼此的未來。',{'bonds':6,'friend':4},{'ordinary_life':True}),C('回答不會','你承認兩人的人生已走向不同方向。',{'truth':2,'friend':-3}),min_age=32),

    E('boy_1','boy','長廊的白髮少年','他獨自站在長廊盡頭，看見你後露出略帶遲疑的微笑：「我們是不是見過？」',C('和他交談','少年告訴了你一個似乎很熟悉的名字。',{'bonds':5,'boy':3},{'boy_bond':True}),C('匆匆離開','你走出好遠，仍覺得身後有一道目光。',{'truth':1}),max_age=36,once=True,weight=3),
    E('boy_2','boy','失落的手冊','少年遞來一本撿到的手冊，最後一頁畫著不屬於這個年代的鐘。',C('一起研究','你們記下圖案，約定日後再尋找答案。',{'truth':5,'boy':3},{'boy_clock':True}),C('當作塗鴉','少年收起手冊，沒有再提這件事。',{'bonds':1}),require={'boy_bond':True}),
    E('boy_3','boy','岔路上的告別','他似乎要離開這個城市，臨走前問你願不願意一起走。',C('陪他同行','你的未來出現新的方向。',{'bonds':8,'wealth':-6,'boy':5},{'boy_travel':True}),C('留在原地','你看著背影縮小，決定守住此刻的生活。',{'wealth':4,'boy':-2}),min_age=24,require={'boy_bond':True}),
    E('boy_4','boy','再次相似的面容','陌生城市裡，你遇見一名與前世少年極像的人，連說話習慣都沒變。',C('上前相認','他雖然不認識你，卻願意聽你說故事。',{'truth':5,'boy':3},{'boy_reunion':True}),C('保持沉默','你將這份熟悉藏在心裡。',{'bonds':-2}),min_life=2),
    E('boy_5','boy','約定的代價','少年為了保護陌生人，打算獨自走向危險。',C('陪他承擔','你們一起渡過危機，卻付出了健康代價。',{'health':-13,'bonds':9,'boy':4},{'boy_saved':True}),C('阻止他冒險','你拉住他的衣袖，兩人選擇尋求其他幫助。',{'wealth':-7,'boy':2}),min_age=28),

    E('girl_1','girl','花影下的少女','少女將一朵小花放在掌心，低聲問：「你相信有些人註定會再見嗎？」',C('回答相信','她露出安心的笑，將花交給了你。',{'bonds':5,'girl':4},{'girl_flower':True}),C('回答不相信','她沒有反駁，只是輕輕合上掌心。',{'truth':1}),max_age=40,once=True,weight=3),
    E('girl_2','girl','埋在土裡的願望','她邀請你把心願寫下，埋在老樹下。',C('寫下心願','她保證會記住埋藏的位置。',{'girl':3,'bonds':3},{'girl_wish':True}),C('替她保管','你收下紙條，成了這個願望的守護者。',{'girl':2,'karma':3},{'girl_paper':True}),require={'girl_flower':True}),
    E('girl_3','girl','陌生的求助','她在街角猶豫許久，終於向你借一筆急需的錢。',C('伸出援手','她記住了你的善意。',{'wealth':-9,'bonds':6,'girl':3},{'girl_helped':True}),C('坦白無法幫忙','她雖然失望，仍向你道謝。',{'bonds':-2}),min_age=22),
    E('girl_4','girl','同一首歌','少女哼出一首你上一世聽過的歌，歌詞甚至一字不差。',C('問她歌的來源','她說是在夢裡聽見的，並教你剩下的旋律。',{'truth':6,'girl':2},{'girl_song':True}),C('靜靜聽完','你們共享一段短暫而平靜的時光。',{'health':3,'bonds':3}),min_life=2),
    E('girl_5','girl','黎明之前','她坦承想離開一直生活的城市，卻害怕失去現有的一切。',C('鼓勵她出發','她終於鼓起勇氣，決定走向自己的未來。',{'karma':5,'girl':2},{'girl_free':True}),C('勸她留下','她留在熟悉的地方，卻偶爾望向遠方。',{'bonds':3,'girl':-1}),min_age=26),

    E('child_1','child','抱著玩偶的孩子','長橋邊，抱著兔子玩偶的孩子找不到回家的路，忐忑地看向你。',C('陪他找家人','你幫孩子回到安全的地方。他送你一枚小小的懷錶吊飾。',{'karma':7,'bonds':4,'child':4},{'child_helped':True}),C('請路人幫忙','你讓附近的店員協助他，自己繼續趕路。',{'karma':2},{'child_referred':True}),max_age=64,once=True,weight=3),
    E('child_2','child','拾起的懷錶','孩子發現自己的懷錶掉在石階上，焦急地尋找。',C('原物歸還','孩子鄭重向你道謝，記住了你的臉。',{'karma':5,'child':3},{'child_watch':True}),C('先查看錶背','背面有一個古怪的環形標誌，你才將錶還給他。',{'truth':4,'child':-1},{'watch_symbol':True}),require={'child_helped':True}),
    E('child_3','child','雨中的小傘','放學路上，孩子站在雨裡，唯一的傘已經破了。',C('把傘借給他','你淋濕了衣服，孩子卻安全地回到家。',{'health':-3,'karma':5,'child':2}),C('一起等雨停','你們在屋簷下聊了很久，最後一起走過積水的道路。',{'bonds':5,'child':2}),max_age=65),
    E('child_4','child','畫中的陌生人','孩子畫了畫像遞給你，畫中人竟與一位前世故人極像。',C('留下畫像','畫紙成了重要的調查線索。',{'truth':5},{'child_drawing':True}),C('誇讚孩子','他開心地把畫送給你，你沒有追問來源。',{'bonds':4,'child':2}),min_life=2),

    E('doctor_m_1','doctor_m','一紙診斷','男醫生建議你在接下來幾年定期回診，但療程相當昂貴。',C('接受療程','你保住了健康，但花掉一部分積蓄。',{'health':15,'wealth':-12,'doctor_m':2}),C('暫時觀察','你的錢包沒有減輕，卻必須承擔風險。',{'health':-8,'wealth':3}),min_age=30),
    E('doctor_m_2','doctor_m','醫院的志工','醫生邀請你協助照顧獨自住院的病人。',C('答應志工','你因此結識了許多不同人生的人。',{'karma':6,'bonds':5,'doctor_m':2},{'hospital_volunteer':True}),C('捐款代替','醫院收到善款，病人們也得到幫助。',{'wealth':-8,'karma':4}),min_age=22),
    E('doctor_m_3','doctor_m','被封存的檢驗','醫生握著一份標上「重複樣本」的文件，神色比平日嚴肅。',C('要求查看','資料指出，你的某些特徵不只出現於這一世。',{'truth':7},{'duplicate_record':True}),C('尊重保密','他沒有繼續說下去，只提醒你小心研究所的人。',{'doctor_m':3}),min_life=2,min_year=2090),
    E('doctor_m_4','doctor_m','急診走廊的抉擇','男醫生走出急診室，將一張費用單放在你面前。「病人還沒等到家屬，治療不能停。我會守住他，你願意幫我嗎？」',C('替病人支付費用','你替陌生人爭取到治療時間。男醫生摘下口罩，鄭重向你道謝。',{'wealth':-13,'karma':12,'doctor_m':4},{'patient_saved':True}),C('一起尋求支援','你和他聯絡公益資源，讓病人得到及時照護。',{'karma':8,'bonds':4,'doctor_m':3},{'hospital_volunteer':True}),min_age=20,once=True,weight=3),

    E('dealer_1','dealer','命運的第一次下注','荷官洗著牌：「用一點健康，換一筆能改變生活的錢。你敢下注嗎？」',C('拒絕交易','她笑著收起牌，似乎對你的謹慎頗感興趣。',{'dealer':1,'karma':2}),C('接受交易','財富如約而至，但你感到身體比從前疲憊。',{'health':-12,'wealth':22,'dealer':3},{'dealer_trade':True}),min_age=20,once=True),
    E('dealer_2','dealer','記憶的賭桌','荷官推出兩張背面相同的牌：「一段記憶，換一個關於未來的答案。」',C('保留記憶','她說你比上一位客人更加珍惜自己。',{'dealer':1,'bonds':2}),C('拿記憶交換','你知道了重要的線索，卻忘記某個與你親近的名字。',{'truth':10,'bonds':-10,'dealer':2},{'lost_memory':True,'dealer_secret':True}),min_life=2),
    E('dealer_3','dealer','生死之間的賭局','荷官將一枚黑色籌碼推到桌沿：「有個交易能讓你立刻結束這一世，換取下一世的線索。」',C('收回籌碼','你決定繼續活完這一世。',{'health':2,'dealer':1}),C('以命下注','你閉上眼睛，將未來押在下一次重生。',{'truth':12,'dealer':4},{'dealer_life':True},True),min_life=2,min_age=28),
    E('dealer_4','dealer','逆轉的價碼','她提醒你：世界上沒有免費的奇蹟，你可以用財富替一名故人改變命運。',C('支付代價','你失去大量財富，一段危險因果因此被修正。',{'wealth':-20,'karma':9,'dealer':2},{'fate_repaired':True}),C('維持原樣','她收回籌碼，你決定承擔眼前的結果。',{'dealer':-1}),min_life=2),
    E('dealer_5','dealer','最後一張牌','荷官說你有資格抽一張封存的牌，但牌面可能讓你陷入危險。',C('不抽牌','你離開賭桌，沒有把命運交給運氣。',{'health':4,'karma':2}),C('翻開牌面','牌面描繪著兩個輪迴者的影子，你記住了那個標誌。',{'truth':8,'health':-9},{'two_players_clue':True}),min_life=3,require={'dealer_trade':True}),

    E('reporter_1','reporter','鏡頭前的問題','記者表示想報導你曾幫助他人的故事，希望拍一張照片。',C('接受採訪','新聞讓更多人願意伸出援手。',{'bonds':7,'karma':4,'reporter':2},{'public_story':True}),C('婉拒採訪','她尊重你的決定，答應不透露姓名。',{'reporter':1}),min_age=22),
    E('reporter_2','reporter','一則異常新聞','她發現數個年代的照片裡出現過外貌相似的人，想聽你的看法。',C('分享線索','你與記者開始共同調查。',{'truth':7,'reporter':4},{'reporter_allied':True}),C('否認相關','她沒有強迫你回答，但似乎不太相信。',{'reporter':-2}),min_life=2),
    E('reporter_3','reporter','真相與公眾','記者找到一份可能影響許多人的秘密檔案，問你是否應該公開。',C('支持公開','社會開始討論事件，也引來研究組織的注意。',{'truth':8,'bonds':-3},{'truth_public':True}),C('暫時保密','你們決定保護證人，先找到更多證據。',{'reporter':3,'karma':3}),min_life=2),
    E('reporter_4','reporter','被竄改的報導','記者指著自己的舊文章：「我確定當年不是這麼寫的。」',C('協助保留原稿','你們留下了世界被改變前的證據。',{'truth':7,'reporter':2},{'changed_history':True}),C('勸她停止追查','她暫時放下調查，卻因此失去一條線索。',{'health':4,'reporter':-3}),min_life=3),

    E('detective_1','detective','熟悉的陌生人','男偵探遞來一張年代久遠的照片，照片上的人與你長得極為相似。',C('追問照片來源','他邀請你一起查閱封存檔案。',{'truth':7,'detective':3},{'detective_case':True}),C('否認認識','偵探收起照片，卻開始留意你的行蹤。',{'detective':-2}),min_life=2,weight=3),
    E('detective_2','detective','並不存在的檔案','偵探說自己追查的嫌疑人，在官方紀錄裡從來沒有出生。',C('與他合作','你們找到第一份跨世文件。',{'truth':8,'detective':4},{'case_solved':True}),C('獨自調查','你獨自查到一部分線索，卻得不到他的協助。',{'truth':3,'detective':-2}),require={'detective_case':True}),
    E('detective_3','detective','警告與邀請','有人要求偵探停止調查，他問你是否還要繼續同行。',C('一起承擔','兩人交換線索，決定面對未知的危險。',{'health':-5,'truth':8,'detective':4},{'detective_ally':True}),C('就此收手','你獲得片刻平靜，但線索可能從此失落。',{'health':5,'truth':-2}),min_life=2),
    E('detective_f_1','detective_f','女偵探的推理','女偵探在地圖上圈出幾個日期：「這些失蹤事件，每隔數十年就會重演。」',C('提供自己的見聞','她把你視為可信的調查夥伴。',{'truth':6,'detective_f':3},{'detective_f_ally':True}),C('先聽她推理','你從她的論證裡找到一條新線索。',{'truth':4}),min_life=2),
    E('detective_f_2','detective_f','沉默的證人','她找到一位不願公開露面的證人，希望由你出面交談。',C('接觸證人','證人交給你一枚刻有輪迴符號的徽章。',{'truth':7,'detective_f':2},{'witness_token':True}),C('保護證人','你決定不逼迫對方，換來她對你的尊重。',{'karma':5,'detective_f':2}),min_life=2),

    E('researcher_1','researcher','重複的實驗','研究員出示一份跨年代資料，聲稱人類的某些記憶可以被保留。',C('參與研究','你接受檢測，獲得一份不可思議的實驗結果。',{'truth':9,'health':-5,'researcher':4},{'lab_participant':True}),C('拒絕參與','他尊重你的選擇，但研究仍在繼續。',{'researcher':-1}),min_life=2,min_year=2100,weight=3),
    E('researcher_2','researcher','被複製的記憶','研究員展示一段與你的前世經歷相符的影像，問你是否願意保留樣本。',C('允許保存','你留下了可追溯的證據，卻必須承擔資料外洩風險。',{'truth':10,'researcher':3},{'memory_archive':True}),C('要求銷毀','他當著你的面刪除樣本，你保住了隱私。',{'karma':3,'researcher':-2}),require={'lab_participant':True}),
    E('researcher_3','researcher','人工輪迴計畫','他宣稱自己打造出能模擬下一次人生的裝置，邀請你進行危險試驗。',C('協助試驗','儀器成功運作，你卻受到劇烈的身體負擔。',{'truth':13,'health':-17,'researcher':3},{'artificial_cycle':True}),C('阻止實驗','你說服他先完成安全審查。',{'health':4,'karma':5,'researcher':1}),min_life=3,min_year=2200),
    E('researcher_4','researcher','無法解釋的數據','研究員發現兩條不可能同時存在的人生紀錄，正在爭論該保留哪一份。',C('兩份都保存','你保住兩條世界線的證據。',{'truth':9},{'parallel_records':True}),C('選擇較安全的一份','研究所暫時避免危機，但另一份資料隨之消失。',{'health':5,'truth':3}),min_life=3,min_year=2250),

    E('mercenary_1','mercenary','危險地帶','傭兵願意帶你穿越混亂地區，但索取一筆不低的報酬。',C('雇用他','他遵守約定，帶你平安抵達目的地。',{'wealth':-11,'health':8,'mercenary':3},{'mercenary_hired':True}),C('自行穿越','你節省費用，途中卻受了傷。',{'wealth':4,'health':-12}),min_age=20,min_year=2060),
    E('mercenary_2','mercenary','不在契約裡的人','傭兵發現路上有人受困，問你要不要繞路救援。',C('改道救人','你們救出受困者，也失去部分物資。',{'wealth':-8,'karma':7,'mercenary':3},{'civilians_saved':True}),C('完成原任務','你們準時抵達，但那段求救聲始終留在心裡。',{'wealth':8,'karma':-4}),min_year=2060),
    E('mercenary_3','mercenary','最後的補給','剩餘的食物只夠一個人用，傭兵將決定權交到你手上。',C('與他平分','你們一起承擔飢餓，並活著走出廢墟。',{'health':-8,'bonds':6,'mercenary':4},{'mercenary_bond':True}),C('全部留給自己','你保住了體力，但失去他的信任。',{'health':6,'mercenary':-5}),min_year=2120,min_age=26),
    E('mercenary_4','mercenary','一筆舊債','他告訴你有人懸賞追捕一名曾經救過他的故人，問你願不願意插手。',C('協助隱藏故人','你成了他真正信任的朋友。',{'wealth':-5,'karma':5,'mercenary':5},{'mercenary_loyal':True}),C('置身事外','傭兵沒有責怪你，卻從此很少再談私事。',{'mercenary':-2}),min_year=2100),

    E('guard_1','guard','門前的守護者','護衛攔住你的去路，表示他必須確認你的身分才能放行。',C('配合查驗','他禮貌地讓開，並記住了你。',{'guard':3,'karma':2},{'guard_trust':True}),C('強行闖入','你受了輕傷，也被他列入注意名單。',{'health':-9,'guard':-4}),min_age=20),
    E('guard_2','guard','不能違背的命令','護衛接到命令，要把一名無辜者交給上級處置。',C('勸他拒絕','他第一次開始質疑自己的職責。',{'karma':7,'guard':3},{'guard_question':True}),C('尊重他的決定','他照章行事，卻難掩內心的遲疑。',{'guard':1,'karma':-3}),min_age=24),
    E('guard_3','guard','替誰擋下危險','護衛準備獨自引開追兵，你只有幾秒鐘可以決定。',C('一起撤離','你們相互扶持，付出代價卻沒有留下任何人。',{'health':-14,'bonds':7,'guard':5},{'guard_saved':True}),C('讓他留下','你順利脫身，他的身影消失在煙霧之中。',{'health':6,'guard':-7},{'guard_sacrifice':True}),min_age=28),
    E('guard_4','guard','交還的徽章','你在廢棄住所裡找到了護衛留下的徽章。',C('保存徽章','徽章象徵著你們曾經許下的承諾。',{'bonds':5,'guard':2},{'guard_badge':True}),C('交給他的家人','家人向你道謝，也告訴你他過去的故事。',{'karma':5,'truth':2}),min_life=2),

    E('rival_1','rival','狹路相逢','銀髮的對手坐在棋盤後，抬眼一笑：「這次，我們要下哪一局？」',C('嘗試和解','他意外地認真聽完你的話，暫時放下敵意。',{'bonds':4,'rival':4},{'rival_peace':True}),C('接受挑戰','一場爭執開始，你也因此更加了解他的實力。',{'health':-5,'truth':3,'rival':-3},{'rival_duel':True}),min_age=22),
    E('rival_2','rival','不能退讓的底線','宿敵提出交易：只要你放棄一名同伴，他就停止干涉你的計畫。',C('拒絕出賣同伴','他對你的固執感到不解，卻有一瞬間露出欣賞。',{'karma':8,'bonds':5,'rival':1},{'loyal_choice':True}),C('接受交易','你獲得資源，卻讓重要的人受到傷害。',{'wealth':18,'bonds':-12,'karma':-9,'rival':-2},{'betrayal':True}),min_age=28),
    E('rival_3','rival','前世的棋局','他擺出一個熟悉的棋局：「你每一次都會在這一步猶豫。」',C('問他是否記得','宿敵承認，自己偶爾會夢見別人的人生。',{'truth':8,'rival':3},{'rival_memory':True}),C('直接落子','你用行動證明自己不打算受前世束縛。',{'truth':3,'rival':-2}),min_life=2),
    E('rival_4','rival','最後的握手','你與宿敵都已筋疲力盡，而前方只剩一條可以共同通過的路。',C('伸手合作','你們第一次為相同的目標並肩而行。',{'bonds':8,'rival':7},{'rival_allied':True}),C('拒絕妥協','你獨自離去，留下未解的恩怨。',{'truth':3,'rival':-4}),min_life=3,min_age=30),

    E('elder_1','elder','喊出舊名的人','老人抬起頭，竟喊出了你上一世使用的名字。「原來這一回，還是你。」',C('追問原因','他取出一本手札，說自己等了你很久。',{'truth':9,'elder':4},{'elder_book':True}),C('假裝沒聽見','老人沒有追上來，只留下意味深長的眼神。',{'elder':-2}),min_life=2,weight=3),
    E('elder_2','elder','手札裡的懷錶','他翻開手札，書頁夾著一幅抱著兔子玩偶的孩子與懷錶的素描。',C('承認曾幫助過他','老人笑了：「原來你還是記起來了。」',{'truth':8,'bonds':9,'elder':5},{'child_elder_truth':True}),C('詢問他如何保存','你得知他曾花了一生研究殘留的記憶。',{'truth':6,'elder':2}),min_life=2,require={'child_helped':True}),
    E('elder_3','elder','被保存的信件','老人將一封無法寄出的信交給你：「它本該在很多年前抵達。」',C('收下信件','信中包含一名故人不曾說出口的願望。',{'bonds':6,'truth':4},{'elder_letter':True}),C('請他親自保管','老人點頭，把信重新夾進書裡。',{'elder':2,'health':2}),min_life=2),
    E('elder_4','elder','告別之前','老人說自己的人生接近終點，想把所有筆記交給你。',C('承接他的研究','你保存了跨世記憶的珍貴資料。',{'truth':12,'elder':3},{'inherited_notes':True}),C('陪他度過今天','你將真相暫時放下，只陪他看了一次夕陽。',{'bonds':10,'elder':4},{'elder_companion':True}),min_life=2,min_age=38),

    E('traveler_1','traveler','燈火中的旅人','戴著斗笠的旅人在人群裡認出你：「你這次走得比之前遠。」',C('請他解釋','他留下一枚標有陌生座標的紙片。',{'truth':7,'traveler':3},{'traveler_clue':True}),C('保持警惕','他不勉強你，只說終有一天會再見。',{'traveler':-1}),min_life=2,weight=3),
    E('traveler_2','traveler','被抹去的地圖','旅人把一張沒有地名的地圖攤開，指著其中一個圓形標誌。',C('記下標記','你找到通往秘密記錄室的線索。',{'truth':8,'traveler':2},{'secret_map':True}),C('先問他的身分','他微笑不答，卻透露自己也曾失去名字。',{'truth':4,'traveler':3}),require={'traveler_clue':True}),
    E('traveler_3','traveler','沒有終點的路','他告訴你，輪迴或許不是牢籠，而是通往某個選擇的漫長道路。',C('相信他的說法','你開始尋找輪迴之外的可能。',{'truth':6,'traveler':4},{'beyond_cycle':True}),C('質疑他的動機','他承認自己隱瞞了一部分真相。',{'truth':5,'traveler':-2}),min_life=3),
    E('traveler_4','traveler','遺失的名字','旅人終於拿出一本舊名冊，其中好幾個名字都和你有關。',C('尋找第一個名字','你找到一段早於第一世的模糊記錄。',{'truth':12,'traveler':3},{'first_name':True}),C('合上名冊','你決定不再讓那些名字定義現在的自己。',{'bonds':5,'karma':4}),min_life=4,min_year=2200),

    E('other_1','other','第二名輪迴者','那人坐在你對面：「看來你終於發現，不只你一個人能重來。」',C('提出合作','你們交換情報，建立脆弱的同盟。',{'truth':8,'other':5},{'other_ally':True}),C('保持敵意','那人笑了笑，似乎早已料到你的反應。',{'truth':3,'other':-4},{'other_enemy':True}),min_life=3,min_year=2160,weight=3),
    E('other_2','other','被改寫的相遇','你原本打算與一名故人見面，對方卻先一步改變了那場約定。',C('質問對方','你知道他正在爭取一個和你相同的機會。',{'truth':5,'other':-3},{'other_conflict':True}),C('重新協商','你們勉強達成了一個新的交換條件。',{'bonds':3,'other':3}),require={'other_ally':True}),
    E('other_3','other','只有一個出口','另一位玩家告訴你，現在的資料只顯示一條離開輪迴的通路。',C('尋找共同方案','你們選擇推翻這個看似唯一的答案。',{'truth':9,'other':6},{'shared_exit':True}),C('自己搶先通過','對方將你視為競爭者，一場新對抗開始。',{'truth':5,'other':-7},{'single_exit':True}),min_life=4,min_year=2200),
    E('other_4','other','關於神明的秘密','另一位玩家說，神明隱瞞了某些不能說出的規則。',C('向神明求證','你決定用親身建立的信任尋找答案。',{'truth':7,'god':2},{'ask_god':True}),C('相信對方','你接受他提供的另一份版本。',{'truth':9,'other':3},{'trust_other':True}),min_life=4),
    E('other_5','other','雙重命運','當兩段生命紀錄交會，系統顯示有機會讓兩人同時保留自我。',C('一起完成計畫','兩份記憶在共同努力下保存。',{'truth':9,'bonds':9,'other':6},{'dual_destiny':True}),C('保護自己的記憶','你保住了自己，卻失去合作的可能。',{'health':8,'other':-5}),min_life=5,min_year=2350),

    E('yu_1','yu','神明留下的名字','余魚伸出手，掌心浮現你前一世使用過的名字：「妳忘記的，我替妳記得。」',C('接過名字','過往的記憶回到心底，你也開始信任他。',{'truth':6,'god':5},{'god_memory':True}),C('不想看過去','他尊重你的決定，收起那道微光。',{'health':4,'god':1}),min_life=2),
    E('yu_2','yu','未說出口的挽留','余魚輕聲問：「若妳找到離開輪迴的方法，還會回來見我嗎？」',C('我想離開','他沒有阻攔，只祝福妳擁有自由。',{'truth':3,'god':-3}),C('我會回來見你','他握住妳的手，像是終於放下心。',{'bonds':7,'god':7},{'god_promise':True}),min_life=2),
    E('yu_3','yu','神明也有願望','余魚說，他偶爾也想像普通人一樣和妳度過一天。',C('邀他同遊','在不屬於任何時代的庭院裡，你們擁有短暫而真實的一日。',{'bonds':8,'god':7},{'god_date':True}),C('提醒他的職責','他收起微笑，重新坐回輪迴之座。',{'truth':4,'god':-2}),min_life=3),
    E('mao_1','mao','被保存的回憶','懋貓指尖浮現一枚淡紫色光點：「這是你曾經忘記的一個願望。」',C('請她歸還','你看見模糊的前世片段，她也放心了一些。',{'truth':6,'god':5},{'god_memory':True}),C('留在她身邊保存','她輕輕合上掌心，說等你準備好再來拿。',{'health':4,'god':2}),min_life=2),
    E('mao_2','mao','神明的願望','懋貓問：「如果有一天，我不再是神明，你還會來找我嗎？」',C('我尊重妳的決定','她點了點頭，似乎還有話沒有說完。',{'god':2,'truth':2}),C('無論如何都會','她微笑著握住你的手，答應記住這句話。',{'bonds':7,'god':7},{'god_promise':True}),min_life=2),
    E('mao_3','mao','紫色的午後','懋貓邀請你在輪迴之外的庭院喝一杯茶，暫時不談命運。',C('陪她留下','那是你們難得不必互相告別的一天。',{'bonds':8,'god':7},{'god_date':True}),C('先回到現世','她送你離開，繼續等待下一次重逢。',{'truth':4,'god':-1}),min_life=3),
]

# 供超過單世事件池時抽取；並非以相同文案重複填滿卡片。
# (角色, 標題, 事件文本, 左選項, 左結果, 右選項, 右結果, 左數值, 右數值)
EXTRA = [
 ('friend','難得的休假','青梅竹馬邀你一起去走走，你最近一直忙著自己的事。','答應出門','你找回一點輕鬆的心情。','繼續工作','你多了一些積蓄，但錯過這次相聚。',{'health':4,'bonds':4,'friend':2},{'wealth':6,'friend':-1}),
 ('boy','遺落的書','無名少年把書借給你，書裡夾著一朵早已乾燥的花。','細心閱讀','書頁讓你想起一些模糊的感受。','原封歸還','他感謝你替他保管書本。',{'truth':3,'boy':2},{'boy':1}),
 ('girl','一張合照','無名少女邀請你在花開的季節留下合照。','留下合照','她高興地說要把照片保存一輩子。','婉拒合照','她雖失望，仍珍惜與你見面的時間。',{'girl':3,'bonds':4},{'girl':-1}),
 ('child','摺紙的禮物','孩童拿著一隻摺紙鳥，猶豫要不要送給你。','開心收下','你收穫了一份單純的善意。','教他摺新的','你們一起完成兩隻新的紙鳥。',{'child':2,'bonds':3},{'child':4,'karma':2}),
 ('doctor_m','醫師的忠告','男醫生建議你改變長期熬夜的習慣。','照著調整','一段時間後，你發現精神好了不少。','繼續熬夜','工作進度提高，身體卻感到吃力。',{'health':8},{'health':-7,'wealth':6}),
 ('dealer','免費的一杯茶','荷官難得沒有端出籌碼，而是邀你在賭桌邊喝茶。','留下聊天','你了解到她也曾有普通人的人生。','禮貌離開','她舉杯向你致意，沒有勉強。',{'dealer':3,'truth':2},{'health':2}),
 ('reporter','未完成的專訪','記者說想蒐集不同世代的人生故事，問你願不願意分享。','分享故事','你的經歷成為一篇溫柔的報導。','替別人推薦','你讓另一個人的故事被世人看見。',{'reporter':3,'bonds':3},{'karma':4}),
 ('detective','日常委託','男偵探正在找一位遺失重要信物的人，請你幫忙。','陪他尋找','你學會了從微小痕跡找出答案。','提供自己的線索','他憑藉你的情報順利結案。',{'detective':3,'truth':2},{'detective':2,'karma':2}),
 ('detective_f','微小的證據','女偵探發現了互相矛盾的證詞，請你說說看法。','相信物證','你們找到更可靠的調查方向。','先聽證人說完','你們發現了原先忽略的情緒和動機。',{'truth':4,'detective_f':2},{'bonds':4,'detective_f':2}),
 ('researcher','桌上的藍色藥劑','研究員邀請你協助整理一批不危險的實驗資料。','加入整理','你熟悉了研究所的日常工作。','婉拒邀請','他給你一本簡單的研究入門書。',{'truth':4,'researcher':3},{'truth':2}),
 ('mercenary','野外的火光','傭兵在營火旁問你，若平安回去，最想做的事是什麼。','談談家人朋友','你們第一次談起工作之外的生活。','談談下一份任務','他認為你是值得合作的同伴。',{'bonds':4,'mercenary':3},{'wealth':4,'mercenary':2}),
 ('guard','交班的夜晚','護衛在寒夜守著大門，面前的茶早已涼了。','送上一杯熱茶','他低聲道謝，緊繃的神情稍微放鬆。','幫他注意四周','你的協助讓這次交班平安結束。',{'guard':3,'karma':2},{'guard':2,'bonds':3}),
 ('rival','另一場棋局','宿敵拿起一枚棋子，表示今天只想公平地比試一次。','認真對局','你們都學到了新的思考方式。','提出平局','他笑著說你倒是很會談條件。',{'truth':4,'rival':2},{'rival':3,'health':2}),
 ('elder','舊書裡的花','老人翻出一朵壓在書頁裡的乾燥花，告訴你它已保存許多年。','聆聽往事','你記下了某個正在消失的故事。','幫忙整理書架','你陪他度過一個安靜的午後。',{'truth':3,'elder':2},{'bonds':4,'elder':2}),
 ('traveler','風塵僕僕','神秘旅人剛從遠方歸來，披風上還沾著路途的塵土。','請他說故事','他談起一座尚未出現在地圖上的城市。','替他準備食物','你們分享簡單的一餐。',{'truth':4,'traveler':2},{'karma':3,'traveler':2}),
 ('other','相同的疑問','另一位玩家問，你認為每一世最值得帶走的是什麼。','選擇回憶','他說這個答案和自己曾經很像。','選擇羈絆','他低頭思索許久，認真地點頭。',{'truth':4,'other':2},{'bonds':4,'other':3}),
]
for i, row in enumerate(EXTRA, 1):
    who,title,story,ln,lr,rn,rr,le,re = row
    EVENTS.append(E('daily_'+str(i),who,title,story,C(ln,lr,le),C(rn,rr,re),
                    min_life=2 if who in ('elder','traveler','other','researcher','detective_f') else 1,
                    min_year=2100 if who in ('researcher','other') else 2026))

# 35 個彼此有不同文字的可收集結局。前面為有明確條件的特殊結局。
ENDINGS = [
 ('god_love','與神明相戀','在無數次告別之後，你與神明終於選擇了彼此。'),
 ('god_guard','永恆的守望','你沒有離開輪迴，卻成為神明漫長歲月裡最熟悉的人。'),
 ('friend_home','平凡的幸福','你放下追逐遠方的念頭，與珍惜的人平靜度過一生。'),
 ('boy_reunion','宿命重逢','你終於在變動的世界裡重新握住那位少年的手。'),
 ('girl_wish','花開之約','埋在樹下的願望終於在這一世悄悄實現。'),
 ('child_legacy','被延續的善意','當年幫助過的孩子，把那份善意傳給了更多人。'),
 ('elder_memory','有人記得','所有名字都已改變，卻仍有人替你記住最初的約定。'),
 ('detective_truth','檔案之外','你和偵探整理出足以證明輪迴存在的珍貴紀錄。'),
 ('reporter_truth','公諸於世','你的故事成了改變世界的報導，讓更多人開始追問真相。'),
 ('science_cycle','人工重生','研究終於揭示輪迴的一部分機制，人類獲得了新的可能。'),
 ('rival_peace','宿敵的和解','漫長的恩怨並未消失，卻在最後變成一場平靜的對話。'),
 ('rival_duel','永遠的對手','你們不斷在不同時代相遇，始終以對手的身分前進。'),
 ('guard_oath','守護的誓言','你與護衛守住了彼此的承諾，並沒有被時光磨去。'),
 ('mercenary_bond','並肩而行','你和傭兵走過危險的土地，也學會把後背交給彼此。'),
 ('dealer_fate','命運的交易','你得到了想要的答案，卻永遠記得曾在賭桌上支付的代價。'),
 ('traveler_road','無名的旅途','你決定繼續旅行，不讓任何一個年代成為最後的終點。'),
 ('other_together','雙重輪迴','兩名輪迴者終於找到不必犧牲彼此的出路。'),
 ('other_alone','唯一的出口','你選擇獨自穿越那扇門，留下另一名輪迴者的故事。'),
 ('child_elder','從孩子到老人','你終於知道，曾經扶起的孩子，如何用一生等到重逢。'),
 ('names_record','被保存的姓名','你找回許多世使用過的名字，也終於明白自己是誰。'),
 ('beyond_rebirth','輪迴之外','你選擇踏進未知的世界，終於不再由死亡決定下一次開始。'),
 ('quiet_life','安穩一生','你沒有發現所有秘密，卻真誠地走完屬於自己的日子。'),
 ('wealth_life','金色年華','你用一生建立了足以庇護自己與親人的財富。'),
 ('kind_life','善意之種','許多微小的善舉在你不知道的地方長成新的希望。'),
 ('lonely_life','孤獨長路','你看見了更多世界，卻很少有人真正走近你的內心。'),
 ('short_life','未竟之年','人生意外停在半途，仍留下足以改變下一世的片段。'),
 ('long_life','百歲之書','你活到高齡，把無數個普通日子寫成厚厚的一生。'),
 ('lost_memories','遺失的名字','你從交易中帶回秘密，卻再也想不起某個熟悉的稱呼。'),
 ('broken_promise','來不及的約定','一封未寄出的信，成為這一世最難忘的遺憾。'),
 ('healer_way','療癒之路','你選擇把時間交給需要照顧的人，幫助許多生命走出困境。'),
 ('distant_star','遠方的星','你總在離別後前進，最終把旅途變成自己的歸宿。'),
 ('world_change','世界的轉折','你的選擇逐漸影響無數陌生人的未來。'),
 ('future_record','未來見證者','你保存了重要的知識，讓後來的人能理解失落的年代。'),
 ('promise_guarded','守住的秘密','有些真相沒有被公開，卻保護了值得珍惜的人。'),
 ('last_rebirth','千年終章','時間走到西元三〇二六年，千年的輪迴終於抵達終點。'),
]
assert len(EVENTS) >= 80 and len(ENDINGS) == 35


# 特殊結局保留探索感，普通／因果結局直接在收藏中顯示判定條件。
SPECIAL_ENDINGS = frozenset(('last_rebirth','god_love','god_guard','other_together','other_alone',
    'beyond_rebirth','child_elder','elder_memory','boy_reunion','girl_wish','friend_home',
    'detective_truth','reporter_truth','science_cycle','rival_peace','rival_duel',
    'guard_oath','mercenary_bond','dealer_fate','traveler_road'))
ENDING_REQUIREMENTS = {
    'child_legacy':'曾幫助迷路的孩子找到家人，且死亡結算時因果 ≥ 35。',
    'names_record':'承接老人的研究筆記；若沒有觸發更優先的結局，真相 ≥ 55 亦可。（找到旅人的第一個名字會優先觸發「無名的旅途」。）',
    'lost_memories':'與荷官交換記憶，留下「失去記憶」的因果紀錄。',
    'broken_promise':'在「未寄出的信」選擇留待以後，留下未拆信件。',
    'future_record':'完成研究員的記憶封存，或保留兩份平行紀錄。',
    'promise_guarded':'取得女偵探證人的信物，而且沒有公開記者查到的真相。',
    'world_change':'死亡結算時，因果 ≥ 65 且真相 ≥ 40。',
    'healer_way':'在男醫生的醫院事件中協助救治病人或擔任志工，且死亡結算時因果 ≥ 40。',
    'wealth_life':'死亡結算時財富 ≥ 85；若沒有其他更優先的結局，財富 ≥ 65 亦可。',
    'kind_life':'死亡結算時因果 ≥ 48，且沒有觸發更優先的結局。',
    'lonely_life':'死亡結算時人際 ≤ 13，且沒有觸發更優先的結局。',
    'short_life':'未滿 40 歲死亡；若其他結局均未符合，健康 < 30 也會進入本結局。',
    'long_life':'90 歲（含）以上死亡，且沒有觸發更優先的結局。',
    'quiet_life':'死亡結算時健康 ≥ 55 且人際 ≥ 55；若沒有其他結局，人際 ≥ 50 也可。',
    'distant_star':'死亡時未符合其他所有結局；這是最後的預設結局。',
}
assert len(SPECIAL_ENDINGS) == 20 and len(ENDING_REQUIREMENTS) == 15
assert SPECIAL_ENDINGS | ENDING_REQUIREMENTS.keys() == {item[0] for item in ENDINGS}

# 每段包含（說話者，文字）；特殊結局會在結局畫面依序播放專屬對話。
ENDING_DIALOGUES = {
 'last_rebirth':[('引路神明','最後的一道門已經開了。這次，我不會再讓你回到起點。'),('你','若我忘了所有名字，你還會記得我嗎？'),('引路神明','我會。但從今天起，你能替自己寫下未來。')],
 'god_love':[('{god}','我看過你無數次轉身離去，卻從未習慣告別。'),('你','這一次，我不想再把你留在身後。'),('{god}','那就留下吧。不是因為命運，而是因為我們選擇彼此。')],
 'god_guard':[('{god}','旁人的一生轉瞬即逝，只有你願意一次又一次回頭。'),('你','我只是想讓你知道，你並不孤單。'),('{god}','那麼，請讓我也守護你的下一次黎明。')],
 'other_together':[('另一位玩家','規則明明寫著，出口只容得下一個人。'),('你','規則是別人寫的，我們可以寫新的。'),('另一位玩家','好。這一回，我們誰也不放棄。')],
 'other_alone':[('另一位玩家','你已經走到門前了。真的不等我嗎？'),('你','我不知道門還會開多久。'),('另一位玩家','那就往前走吧。只是希望有一天，你不會後悔。')],
 'beyond_rebirth':[('神秘旅人','你終於明白了，輪迴不是世上唯一的道路。'),('你','但門後會不會什麼都沒有？'),('神秘旅人','我也不知道。正因如此，它才真正屬於你。')],
 'child_elder':[('老人','當年那個在橋邊哭泣的孩子，你還記得嗎？'),('你','原來……一直等在這裡的是你。'),('老人','你曾經替我找到回家的路。這次換我替你找回名字。')],
 'elder_memory':[('老人','你忘了的事情，我都寫在這本手札裡。'),('你','為什麼要花一輩子替我保留？'),('老人','因為有人記得，約定就不算消失。')],
 'boy_reunion':[('無名少年','我又夢見那條長廊了。這次你沒有從我身邊走過。'),('你','我找了你不只一世。'),('無名少年','那我們就從今天開始，重新認識彼此。')],
 'girl_wish':[('無名少女','樹下的紙條，你猜我寫了什麼？'),('你','希望有一天，我們還能重逢？'),('無名少女','不。我寫的是：希望重逢時，我們都能幸福。')],
 'friend_home':[('青梅竹馬','這次還要去很遠的地方嗎？'),('你','我走了那麼多路，才發現想見的人就在這裡。'),('青梅竹馬','那就回家吧。晚餐還熱著。')],
 'detective_truth':[('男偵探','檔案裡沒有你，但你留下的痕跡到處都是。'),('你','終於有人願意相信我的故事了。'),('男偵探','不是相信而已。我會陪你把證據查到最後。')],
 'reporter_truth':[('記者','一旦刊登，就再也不能把這件事收回去了。'),('你','有人需要知道真相，即使它讓人不安。'),('記者','好。那我就用自己的名字，為這篇報導負責。')],
 'science_cycle':[('研究員','數據是真的。生命的記憶，竟然可以跨過死亡。'),('你','那就別讓這個發現只剩冰冷的編號。'),('研究員','我會記住：每一筆紀錄背後，都是一個人的人生。')],
 'rival_peace':[('宿敵','這一次，你竟然選擇把手伸向我。'),('你','打贏你很多次，也不如讓我們都能走下去。'),('宿敵','那麼，從今以後就暫時休戰吧。')],
 'rival_duel':[('宿敵','又是你。連輪迴都沒辦法讓我們分出勝負。'),('你','所以，下一局還打嗎？'),('宿敵','當然。我會一直等到你認輸的那一天。')],
 'guard_oath':[('護衛','我曾發誓守住你，卻沒想到你也會回頭救我。'),('你','承諾不是要你一個人承擔。'),('護衛','那我們就一起活著，直到這條路走完。')],
 'mercenary_bond':[('傭兵','以前的我從不把後背交給任何人。'),('你','現在呢？'),('傭兵','只要你在，我就敢往前走。')],
 'dealer_fate':[('荷官','牌已經翻開。你得到答案，代價也已付清。'),('你','如果重來，我或許還會做出一樣的選擇。'),('荷官','我就喜歡這樣的客人。下次，也別忘了看清籌碼。')],
 'traveler_road':[('神秘旅人','你已經找回名字，接下來還想去哪裡？'),('你','去一個從沒有人替我決定方向的地方。'),('神秘旅人','那就出發吧。這次，旅途沒有終點。')],
 'child_legacy':[('長大的孩子','小時候有人扶了我一把，所以我也想幫助別人。'),('你','原來那天做的小事，會走得這麼遠。'),('長大的孩子','你給我的不是答案，是繼續向前的勇氣。')],
 'names_record':[('老人','這本名冊裡，每一頁都寫著你活過的證明。'),('你','名字不一樣，卻都是我。'),('老人','那就好好收著，別再把自己遺忘。')],
 'lost_memories':[('荷官','你贏得想要的線索，卻忘了那個人的名字。'),('你','為什麼心裡還會覺得這麼難過？'),('荷官','交易從不收走感情，只收走你記得它的理由。')],
 'broken_promise':[('青梅竹馬','你說過還有很多時間，信卻一直沒有拆開。'),('你','我以為明天總會來。'),('青梅竹馬','有些話錯過了，就只能留在昨天。')],
 'future_record':[('研究員','我把這些記錄留下來了，未來的人也許能讀懂。'),('你','希望他們別只看見數據。'),('研究員','我會把你的故事，放在第一頁。')],
 'promise_guarded':[('女偵探','有些證據能公開，有些名字卻值得被保護。'),('你','我們做的選擇，真的正確嗎？'),('女偵探','至少那些人能平安生活。這也是一種答案。')],
 'healer_way':[('男醫生','那天你幫助的病人，已經康復出院了。'),('你','我只是做了自己能做的事。'),('男醫生','對別人而言，那可能就是重新活下去的機會。')],
}

# 關鍵事件有分支專屬對話，顯示於滑卡選擇結果，不與普通日常混用。
EVENT_DIALOGUES = {
 'boy_1': {'left':[('無名少年','明明是第一次見面，我卻覺得已經等了你很久。')],
           'right':[('無名少年','沒關係。若真有緣，我們會再見。')]},
 'child_1': {'left':[('孩童','謝謝你！等我長大以後，也要幫別人找到回家的路。')],
             'right':[('孩童','我會在這裡等家人，謝謝你替我找人幫忙。')]},
 'elder_2': {'left':[('老人','這枚懷錶我一直留著，只為了有一天能親手還給你。')],
             'right':[('老人','不是所有答案，都需要在同一天揭曉。')]},
 'doctor_m_4': {'left':[('男醫生','謝謝你。這次我們真的一起把病人從危險中帶回來了。')],
                'right':[('男醫生','一個人做不到的事，兩個人也許就有辦法。')]},
 'dealer_3': {'left':[('荷官','懂得收手，也是賭桌上最難的一種勇氣。')],
              'right':[('荷官','契約成立。下一世見，勇敢的客人。')]},
 'reporter_3': {'left':[('記者','那就讓每一個人親眼看看被藏起來的真相。')],
                'right':[('記者','在公開之前，我們先守住證人的安全。')]},
 'other_3': {'left':[('另一位玩家','你真的相信，我們能一起走出去嗎？')],
             'right':[('另一位玩家','我記住你的選擇了。下一次再見，我不會手下留情。')]},
 'yu_2': {'right':[('余魚','我會一直等妳，直到我們不必再說再見。')]},
 'mao_2': {'right':[('懋貓','那就說好了，無論變成什麼樣子，都要再見。')]},
}

# 特殊結局以主要對話角色的立繪作為結尾卡背景；神明依玩家固定性別選取。
ENDING_ACTORS = {
    'last_rebirth':'god','god_love':'god','god_guard':'god',
    'other_together':'other','other_alone':'other','beyond_rebirth':'traveler',
    'child_elder':'elder','elder_memory':'elder','boy_reunion':'boy','girl_wish':'girl',
    'friend_home':'friend','detective_truth':'detective','reporter_truth':'reporter',
    'science_cycle':'researcher','rival_peace':'rival','rival_duel':'rival',
    'guard_oath':'guard','mercenary_bond':'mercenary','dealer_fate':'dealer',
    'traveler_road':'traveler','child_legacy':'child','names_record':'elder',
    'lost_memories':'dealer','broken_promise':'friend','future_record':'researcher',
    'promise_guarded':'detective_f','healer_way':'doctor_m',
}
