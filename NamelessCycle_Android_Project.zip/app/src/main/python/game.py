#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""無名輪迴：只需 Python 3.9+，無須 pip 安裝套件。
執行 python game.py；瀏覽器進入 http://127.0.0.1:8765
可用 python game.py --port 8766 --no-browser 修改埠號/關閉自動開啟。
"""
import argparse
from copy import deepcopy
import json
import mimetypes
import os
from pathlib import Path
import random
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit
from story import (CHARACTERS, EVENTS, ENDINGS, SPECIAL_ENDINGS, ENDING_REQUIREMENTS, ENDING_DIALOGUES, EVENT_DIALOGUES, ENDING_ACTORS)

BASE = Path(os.environ.get('NML_BASE_DIR') or Path(__file__).resolve().parent)
SAVE = BASE / 'data' / 'save.json'
SAVE.parent.mkdir(parents=True, exist_ok=True)
ENDINGS_BY_ID = {x[0]: x for x in ENDINGS}
EVENTS_BY_ID = {e['id']: e for e in EVENTS}
STATE = None
LOCK = threading.RLock()
# 三個獨立的手動節點存檔，不會被平常的自動續玩覆蓋。
SLOT_COUNT = 3

# 圖鑑使用獨立檔案，建立新角色、重生或讀取手動存檔都不會覆寫。
CODEX = BASE / 'data' / 'character_codex.json'
CHARACTER_DESCRIPTIONS = {
    'yu': '女性玩家的引路神明，守著輪迴長廊與你的每一世名字。',
    'mao': '男性玩家的引路神明，在輪迴起點與歸途等待你。',
    'boy': '在長廊與不同年代出現的少年，似乎與你的前世有關。',
    'girl': '與花朵、願望及跨世約定有關的少女。',
    'dealer': '掌管籌碼和交易的荷官，代價可能是財富、記憶，甚至生命。',
    'reporter': '追尋異常新聞與年代謎團的記者。',
    'detective': '調查失蹤事件和不存在檔案的男偵探。',
    'detective_f': '擅長分析矛盾證詞和保護證人的女偵探。',
    'researcher': '研究記憶、樣本和人工輪迴的研究員。',
    'mercenary': '在危險任務中與你建立信任的傭兵。',
    'guard': '將誓言和同伴安危看得很重的護衛。',
    'friend': '陪伴你成長、也可能與你錯過的青梅竹馬。',
    'rival': '在不同人生裡與你較量的宿敵。',
    'child': '曾在長橋邊迷路、抱著玩偶的孩子。',
    'elder': '保存舊信、懷錶與跨世手札的老人。',
    'traveler': '知道部分輪迴秘密、持有奇異地圖的旅人。',
    'other': '同樣經歷重生的另一位輪迴者。',
    'doctor_m': '關心病人與醫療倫理，也願意和你一起救人的男醫生。',
}


def read_codex():
    try:
        data = json.loads(CODEX.read_text(encoding='utf-8'))
        entries = data.get('entries', {}) if isinstance(data, dict) else {}
        return {key: val for key,val in entries.items() if key in CHARACTERS and isinstance(val,dict)}
    except (OSError, ValueError, TypeError):
        return {}


def write_codex(entries):
    CODEX.parent.mkdir(parents=True,exist_ok=True)
    tmp=CODEX.with_suffix('.tmp')
    tmp.write_text(json.dumps({'version':1,'entries':entries},ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(CODEX)


def codex_entry(who, s):
    return {'first_seen':time.strftime('%Y-%m-%d %H:%M'),
            'life':s.get('life',1),'player_name':s.get('name','無名之人')}


def unlock_character(who):
    if who not in CHARACTERS or not isinstance(STATE,dict):return False
    entries=read_codex()
    if who in entries:return False
    entries[who]=codex_entry(who,STATE)
    write_codex(entries)
    return True


def encountered_in_state(s):
    if not isinstance(s,dict) or not s.get('gender'):return set()
    found={'yu' if s.get('gender')=='female' else 'mao'}
    for eid in list(s.get('life_seen',[]))+list(s.get('global_seen',[]))+[s.get('event_id')]:
        if not isinstance(eid,str):continue
        if eid.startswith(('intro_','rebirth_intro_')):continue
        event=EVENTS_BY_ID.get(eid)
        if event and event['who'] in CHARACTERS:
            found.add(event['who'])
        elif eid.startswith('interlude_'):
            try:
                from story import EXTRA
                found.add(EXTRA[int(eid.rsplit('_',1)[1])%len(EXTRA)][0])
            except (ValueError, IndexError):pass
    return found & CHARACTERS.keys()


def sync_legacy_codex():
    # 兼容 v2.1 以前的進度：從目前角色和三格手動存檔回填已見角色。
    entries=read_codex()
    original=len(entries)
    candidates=([STATE] if isinstance(STATE,dict) else [])
    candidates += [item['state'] for item in read_slots().values()
                   if isinstance(item,dict) and isinstance(item.get('state'),dict)]
    for s in candidates:
        for who in encountered_in_state(s):
            if who not in entries:
                # 舊版未儲存初遇日期；不要用升級時間冒充真正初遇時間。
                entries[who]={'first_seen':'舊版紀錄補登','life':s.get('life') if any(
                    EVENTS_BY_ID.get(eid,{}).get('who')==who for eid in s.get('life_seen',[])) else None,
                    'player_name':s.get('name','無名之人')}
    if len(entries)>original:write_codex(entries)


def codex_catalog():
    entries=read_codex()
    return [{'id':who,'name':name if who in entries else '？？？',
             'unlocked':who in entries,
             'image':'/assets/'+img if who in entries else None,
             'description':CHARACTER_DESCRIPTIONS.get(who,'一位在輪迴中出現的人物。') if who in entries else '',
             'first_seen':entries.get(who,{}).get('first_seen',''),
             'first_life':entries.get(who,{}).get('life'),
             'first_player':entries.get(who,{}).get('player_name','')}
            for who,(name,img) in CHARACTERS.items()]



def slots_file():
    return SAVE.with_name('checkpoints.json')


def read_slots():
    try:
        raw = json.loads(slots_file().read_text(encoding='utf-8'))
        return raw if isinstance(raw, dict) else {}
    except (OSError, ValueError):
        return {}


def slots_summary():
    raw = read_slots()
    result = []
    for num in range(1, SLOT_COUNT + 1):
        item = raw.get(str(num))
        if isinstance(item, dict) and isinstance(item.get('state'), dict):
            s = item['state']
            result.append({'slot': num, 'occupied': True,
                           'name': s.get('name','無名之人'), 'gender': s.get('gender','female'),
                           'life': s.get('life',1), 'year': s.get('year',2026), 'age': s.get('age',18),
                           'label': item.get('label','重要節點'), 'saved_at': item.get('saved_at','')})
        else:
            result.append({'slot': num, 'occupied': False})
    return result


def validate_slot(num):
    if type(num) is not int or not 1 <= num <= SLOT_COUNT:
        raise ValueError('存檔欄位必須是 1～3。')
    return num


def mark_checkpoint(label):
    STATE['checkpoint_ready'] = True
    STATE['checkpoint_label'] = label


def save_slot(num):
    num = validate_slot(num)
    if not STATE or not STATE.get('checkpoint_ready') or STATE.get('stage') not in ('card','ending'):
        raise ValueError('只有抵達重要節點或本世結局時，才能進行手動存檔。')
    data = read_slots()
    data[str(num)] = {'label': STATE.get('checkpoint_label','重要節點'),
                      'saved_at': time.strftime('%Y-%m-%d %H:%M'),
                      'state': deepcopy(STATE)}
    dest = slots_file()
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(dest)
    return public_state()


def load_slot(num):
    global STATE
    num = validate_slot(num)
    entry = read_slots().get(str(num))
    if not isinstance(entry,dict) or not isinstance(entry.get('state'),dict):
        raise ValueError('這個欄位沒有存檔。')
    existing_collection = list(STATE.get('collection',[])) if STATE else []
    existing_sound = STATE.get('sound',False) if STATE else False
    existing_fx = STATE.get('effects_sound',True) if STATE else True
    STATE = migrate_legacy_state(deepcopy(entry['state']))
    STATE['collection'] = list(dict.fromkeys(existing_collection + STATE.get('collection',[])))
    STATE['sound'] = existing_sound
    STATE['effects_sound'] = existing_fx
    STATE.setdefault('checkpoint_ready',False)
    STATE.setdefault('checkpoint_label','')
    sync_legacy_codex()
    save()
    return public_state()



def migrate_legacy_state(s):
    """讓 v1.7 舊存檔也能在移除女醫生後正常續玩，且不清除既有因果。"""
    if not isinstance(s, dict): return s
    if str(s.get('event_id','')).startswith('doctor_f_'):
        s['event_id'] = 'doctor_m_4'
    s.get('favor',{}).pop('doctor_f',None)
    s.setdefault('tutorial_seen',True)  # 舊角色不會被強制重新教學。
    return s

STAT_KEYS = ('health', 'wealth', 'bonds', 'karma', 'truth')
DEFAULT_STATS = {'health': 80, 'wealth': 45, 'bonds': 45, 'karma': 0, 'truth': 0}

GOD_ENDING_VARIANTS = {
    'god_love': {
        'yu': ('月下之約', '在一次次輪迴與重逢之後，你與余魚終於不再只是引路與被引路的人，而是真正選擇彼此的戀人。', [('{god}','我曾送妳走進一世又一世，卻從沒學會好好把妳留下。'),('你','那這一次，就別再只站在輪迴盡頭看著我了。'),('{god}','好。從今以後，我不是送妳離開的人，而是陪妳一起走下去的人。'),('你','那就約好了，這次不是短暫重逢，而是永遠同行。')]),
        'mao': ('星庭相守', '你在漫長輪迴之間一次次回望，最後與懋貓在星庭深處相認。從此，她不再只是引路神明，也是願意與你相守的人。', [('{god}','我看過你在無數人生裡跌跌撞撞，卻每一次都還是走回我面前。'),('你','因為我知道，妳一直都在等我。'),('{god}','那麼這一次，換我走向你。不是作為神明，而是作為想陪在你身邊的人。'),('你','好，那我們就不再把重逢留給下一世。')])
    },
    'god_guard': {
        'yu': ('潮聲守望', '即使沒有真正停留在彼此身邊，你仍成了余魚漫長歲月裡最重要的牽掛。你們在無數輪迴之間彼此守望，從未遺忘。', [('{god}','妳總說還有下一世，可我最怕的，從來都不是等待。'),('你','那你害怕的是什麼？'),('{god}','我怕某一天，連妳也不記得曾有人在終點等妳。'),('你','那就讓我一次次回來，告訴你：我一直都記得。')]),
        'mao': ('紫庭長伴', '你沒有離開輪迴，也沒有真正擁有她，卻成為懋貓最熟悉、最溫柔的例外。即使歲月漫長，你們仍彼此守著下一次相見。', [('{god}','神明的時間很長，長到許多名字都會被風帶走。'),('你','但我想成為那個，會一次次走回妳身邊的人。'),('{god}','若真是如此，我就會一直在這裡，替你留一盞不熄的燈。'),('你','那我也會一直回來，直到妳不再需要獨自等待。')])
    }
}

def ending_meta(eid):
    base = ENDINGS_BY_ID.get(eid, ENDINGS_BY_ID['quiet_life'])
    title, desc = base[1], base[2]
    lines = ENDING_DIALOGUES.get(eid, [])
    if eid in GOD_ENDING_VARIANTS:
        deity = deity_id()
        title, desc, lines = GOD_ENDING_VARIANTS[eid][deity]
    return {'id': eid, 'title': title, 'description': desc, 'dialogues': lines}


def read_save():
    try:
        return migrate_legacy_state(json.loads(SAVE.read_text(encoding='utf-8'))) if SAVE.exists() else None
    except (OSError, ValueError):
        return None


def save():
    SAVE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SAVE.with_suffix('.tmp')
    tmp.write_text(json.dumps(STATE, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(SAVE)


def deity_id():
    return 'yu' if STATE['gender'] == 'female' else 'mao'


def card_data(e):
    who = deity_id() if e['who'] == 'god' else e['who']
    name, img = CHARACTERS[who]
    unlock_character(who)
    return {'id': e['id'], 'who': who, 'name': name, 'image': '/assets/'+img,
            'title': e['title'], 'story': e['story'],
            'left': e['choices'][0]['label'], 'right': e['choices'][1]['label']}


def intro_event(index=1):
    female = deity_id() == 'yu'
    pages = {
        1: {
            'title': '輪迴的起點',
            'story': '月華在長廊盡頭流轉，餘暉與星光交錯。引路神明余魚緩緩朝你伸出手，像是早已在這裡等了很久。',
            'left': '詢問這裡是哪裡', 'right': '先聽他開口',
            'lres': '余魚輕聲說，這裡是每一世開始前的輪迴之間。', 'rres': '他垂眸一笑，像是默許你先把不安交給他。'
        },
        2: {
            'title': '引路神明的職責',
            'story': '余魚告訴你，他負責將每個來到此地的靈魂送往下一世。有人帶著遺憾離開，有人帶著希望重生，而你也將做出自己的選擇。',
            'left': '詢問他看過多少輪迴', 'right': '詢問他是否記得每個人',
            'lres': '他說自己早已數不清那些離去與回來的背影。', 'rres': '他回答，並不是所有名字都能被留下，但他會盡力記得重要的人。'
        },
        3: {
            'title': '滑卡規則',
            'story': '他將視線落在你手中的命運卡片上，提醒你：從今以後每一次左右滑動，都是替這一世做出的抉擇；健康、財富、人際、因果與真相，都會因此改寫。',
            'left': '詢問滑卡規則', 'right': '詢問輪迴代價',
            'lres': '他解釋：向左與向右，都代表不同人生方向；每個選擇都會留下痕跡。', 'rres': '他低聲提醒：得到一些東西時，也可能會失去另一些東西。'
        },
        4: {
            'title': '踏入第一世',
            'story': '最後，余魚望向輪迴長門外的晨光，示意你該真正走進這一世了。你的名字、故事與緣分，都將從此刻開始書寫。',
            'left': '請他陪你一起走', 'right': '獨自走向前方',
            'lres': '余魚答應會在輪迴盡頭等你，也會記得你每一世的名字。', 'rres': '你深吸一口氣，決定親自走向第一世，而他會在背後守望。'
        }
    }
    if not female:
        pages = {
            1: {
                'title': '輪迴的起點',
                'story': '紫白色的長廊靜靜延伸，月色與薄霧在腳邊流淌。引路神明懋貓向你伸出手，像是在迎接終於抵達此處的靈魂。',
                'left': '詢問這裡是哪裡', 'right': '先聽她開口',
                'lres': '懋貓柔聲說，這裡是每一世開始前的輪迴之間。', 'rres': '她帶著淡淡笑意，示意你先別緊張。'
            },
            2: {
                'title': '引路神明的職責',
                'story': '懋貓告訴你，她會陪每個靈魂站在起點之前，等對方準備好，再送往下一段人生。她見過許多人遺忘，也見過少數人始終記得。',
                'left': '詢問她看過多少輪迴', 'right': '詢問她會不會感到寂寞',
                'lres': '她輕輕搖頭，說自己早已數不清那些來去的歲月。', 'rres': '她沉默片刻，最後只說：若有人願意回頭，寂寞就沒有那麼長。'
            },
            3: {
                'title': '滑卡規則',
                'story': '她指向將陪伴你一世的命運卡片，解釋左右滑卡就是你對人生做出的選擇。人際、真相、因果與健康，都會隨著抉擇而改變。',
                'left': '詢問滑卡規則', 'right': '詢問輪迴代價',
                'lres': '她告訴你：卡片滑出的方向不同，會將你帶往不同的人生。', 'rres': '她提醒你：輪迴不只是重來，而是帶著痕跡繼續前行。'
            },
            4: {
                'title': '踏入第一世',
                'story': '長門之外已亮起第一世的晨光。懋貓望著你，問你是否準備好成為這一世的自己，並真正走進屬於你的故事。',
                'left': '請她陪你一起走', 'right': '獨自走向前方',
                'lres': '她點頭答應，說自己會記得你每一世的名字，也會在輪迴盡頭等你回來。', 'rres': '你選擇獨自走向前方，而她會在輪迴之間替你守住歸途。'
            }
        }
    page = pages.get(index, pages[max(pages.keys())])
    return {'id':f'intro_{index}','who':'god','title':page['title'],'story':page['story'],
            'choices':[{'label':page['left'],'result':page['lres'],'effects':{'truth':2},'flags':{},'die':False},
                       {'label':page['right'],'result':page['rres'],'effects':{'god':2,'bonds':1},'flags':{},'die':False}]}


def rebirth_event():
    n=STATE['life']
    if deity_id() == 'yu':
        text = '余魚把上一世的名字寫進光裡：「這是妳的第 '+str(n)+' 世。即使世界變了，我依然在這裡。」'
        l,r='問他前世的事','謝謝他一直等待'
        lr,rr='他告訴妳一部分曾經發生的事。','他的目光柔和了些：「去吧，這一世也要好好活著。」'
    else:
        text = '懋貓在輪迴長廊等著你：「第 '+str(n)+' 世了。這次，又想成為什麼樣的人呢？」'
        l,r='問她記不記得','與她約定再見'
        lr,rr='她點頭：「我記得，所有的名字我都留著。」','懋貓輕輕握住你的手：「我會在這裡等你。」'
    return {'id':'rebirth_intro_'+str(n),'who':'god','title':'再一次醒來','story':text,
            'choices':[{'label':l,'result':lr,'effects':{'truth':3,'god':2},'flags':{},'die':False},
                       {'label':r,'result':rr,'effects':{'bonds':3,'god':3},'flags':{},'die':False}]}


def get_current_event():
    eid = STATE.get('event_id')
    if eid and eid.startswith('intro_'): return intro_event(int(eid.rsplit('_',1)[1]))
    if eid and eid.startswith('rebirth_intro_'): return rebirth_event()
    e = EVENTS_BY_ID.get(eid)
    if e is None and eid and eid.startswith('interlude_'):
        # 跨程式重啟後，仍能恢復長壽周目臨時產生的事件。
        from story import EXTRA, E, C
        try:
            index = int(eid.rsplit('_',1)[1]) % len(EXTRA)
            who,title,story,ln,lr,rn,rr,le,re = EXTRA[index]
            e = E(eid,who,title,story,C(ln,lr,le),C(rn,rr,re))
            EVENTS_BY_ID[eid] = e
        except (ValueError,IndexError):
            pass
    return e


def can_offer(e):
    if e['id'] in STATE['life_seen']: return False
    if e['once'] and e['id'] in STATE['global_seen']: return False
    if e['min_life'] > STATE['life'] or e['min_year'] > STATE['year']: return False
    if not(e['min_age'] <= STATE['age'] <= e['max_age']): return False
    for k, needed in e['require'].items():
        if STATE['flags'].get(k) != needed: return False
    if e['who'] in ('yu','mao') and e['who'] != deity_id(): return False
    return True


def choose_event():
    eligible = [e for e in EVENTS if can_offer(e)]
    if not eligible:
        # 少數長壽周目用新的生活事件替補，仍保留對應角色與各自不同的文本。
        from story import EXTRA, E, C
        slot = STATE['event_num'] % len(EXTRA)
        who,title,story,ln,lr,rn,rr,le,re=EXTRA[slot]
        e=E('interlude_'+str(STATE['life'])+'_'+str(STATE['event_num']),who,title,
            story,C(ln,lr,le),C(rn,rr,re))
        EVENTS_BY_ID[e['id']]=e
        return e
    weights=[]
    for e in eligible:
        w=e.get('weight',1)
        if e['who'] in ('yu','mao') and STATE['life']>1: w+=1
        if e['who'] in STATE.get('favor',{}) and STATE['favor'][e['who']] >= 3: w+=1
        weights.append(w)
    return random.choices(eligible,weights=weights,k=1)[0]


def public_state():
    if not STATE: return {'started':False,'endings_total':len(ENDINGS),'slots':slots_summary(),
                          'codex':codex_catalog()}
    result = {k:STATE[k] for k in ('name','gender','life','age','year','stats','event_num','stage','sound','history','last_ending','final')}
    result.update({'started':True,'god':CHARACTERS[deity_id()][0],
                   'god_image':'/assets/'+CHARACTERS[deity_id()][1],
                   'collection':[{'id':k,'title':ending_meta(k)['title'],'description':ending_meta(k)['description']}
                                  for k in STATE['collection'] if k in ENDINGS_BY_ID],
                   'endings_total':len(ENDINGS),'favor':STATE['favor'],
                   'effects_sound':STATE.get('effects_sound',True),
                   'checkpoint_ready':STATE.get('checkpoint_ready',False),
                   'checkpoint_label':STATE.get('checkpoint_label',''),
                   'slots':slots_summary(),
                   'tutorial_seen':STATE.get('tutorial_seen',True),
                   'endings_catalog':[{'id':eid,'title':ending_meta(eid)['title'] if (eid not in SPECIAL_ENDINGS or eid in STATE['collection']) else '？？？・特殊結局',
                        'description':ending_meta(eid)['description'] if eid in STATE['collection'] else '',
                        'requirement':ENDING_REQUIREMENTS.get(eid,'特殊結局・觸發方式保密'),
                        'special':eid in SPECIAL_ENDINGS,'unlocked':eid in STATE['collection']}
                         for eid,title,desc in ENDINGS]})
    if STATE['stage'] in ('card','result'):
        e=get_current_event()
        result['card']=card_data(e) if e else None
    result['codex']=codex_catalog()
    if STATE['stage']=='result': result['outcome']=STATE.get('outcome')
    if STATE['stage']=='ending':
        eid = STATE.get('last_ending','quiet_life')
        meta = ending_meta(eid)
        actor=ENDING_ACTORS.get(eid,'god')
        if actor=='god':actor=deity_id()
        result['ending']={'id':eid,'title':meta['title'],'description':meta['description'],'reason':STATE.get('death_reason',''),
                          'image':'/assets/'+CHARACTERS[actor][1],
                          'special': eid in SPECIAL_ENDINGS,
                          'dialogues':[{'speaker':CHARACTERS[deity_id()][0] if speaker=='{god}' or speaker=='引路神明' else speaker,
                                        'text':line} for speaker,line in meta['dialogues']]}
    return result


def new_game(name, gender, keep_collection=True):
    global STATE
    prev = STATE or {}
    STATE = {'name':name[:18].strip() or '無名之人','gender':gender,'life':1,
             'birth_year':2008,'age':18,'year':2026,
             'stats':DEFAULT_STATS.copy(),'favor':{'god':0},'flags':{},
             'life_seen':[],'global_seen':[],'event_id':'intro_1','event_num':0,
             'stage':'card','outcome':None,'death_reason':'','last_ending':None,
             'collection':list(prev.get('collection',[])) if keep_collection else [],
             'history':[],'final':False,'sound':prev.get('sound',True),
             'effects_sound':prev.get('effects_sound',True),
             'checkpoint_ready':True,'checkpoint_label':'第一世・神明引路',
             'tutorial_seen':False}
    save()
    return public_state()


def settle_ending():
    s=STATE['stats']; f=STATE['flags']; v=STATE['favor']
    special=[
        ('last_rebirth',STATE['final']),
        ('god_love', f.get('god_date') and f.get('god_promise') and v.get('god',0)>=12),
        ('god_guard',v.get('god',0)>=20),
        ('other_together',f.get('dual_destiny') or f.get('shared_exit')),
        ('other_alone',f.get('single_exit')),
        ('beyond_rebirth',f.get('beyond_cycle') and s['truth']>=65),
        ('child_elder',f.get('child_elder_truth')),
        ('elder_memory',f.get('elder_book') and f.get('elder_letter')),
        ('boy_reunion',f.get('boy_reunion') and v.get('boy',0)>=6),
        ('girl_wish',f.get('girl_wish') and f.get('girl_flower')),
        ('friend_home',f.get('ordinary_life') or f.get('friend_confession') and v.get('friend',0)>=6),
        ('detective_truth',f.get('case_solved') and s['truth']>=35),
        ('reporter_truth',f.get('truth_public')),
        ('science_cycle',f.get('artificial_cycle')),
        ('rival_peace',f.get('rival_allied') or f.get('rival_peace') and v.get('rival',0)>5),
        ('rival_duel',f.get('rival_duel') and v.get('rival',0)<0),
        ('guard_oath',f.get('guard_saved')),
        ('mercenary_bond',f.get('mercenary_bond') or f.get('mercenary_loyal')),
        ('dealer_fate',f.get('dealer_life') or f.get('dealer_secret')),
        ('traveler_road',f.get('first_name') or f.get('secret_map')),
        ('healer_way',s['karma']>=40 and (f.get('patient_saved') or f.get('hospital_volunteer'))),
        ('child_legacy',f.get('child_helped') and s['karma']>=35),
        ('names_record',f.get('inherited_notes') or f.get('first_name')),
        ('lost_memories',f.get('lost_memory')),
        ('broken_promise',f.get('unopened_letter')),
        ('future_record',f.get('memory_archive') or f.get('parallel_records')),
        ('promise_guarded',f.get('witness_token') and not f.get('truth_public')),
        ('world_change',s['karma']>=65 and s['truth']>=40),
        ('wealth_life',s['wealth']>=85),
        ('kind_life',s['karma']>=48),
        ('lonely_life',s['bonds']<=13),
        ('short_life',STATE['age']<40),
        ('long_life',STATE['age']>=90),
        ('quiet_life',s['health']>=55 and s['bonds']>=55),
    ]
    for eid,ok in special:
        if ok: return eid
    # 其他人生依主要傾向分流，使所有結局能被不同選擇解鎖。
    if s['wealth']>=65: return 'wealth_life'
    if s['truth']>=55: return 'names_record'
    if s['bonds']>=50: return 'quiet_life'
    if s['health']<30: return 'short_life'
    return 'distant_star'


def die(reason):
    STATE['death_reason']=reason
    STATE['final']=STATE['year']>=3026
    eid=settle_ending()
    STATE['last_ending']=eid
    if eid not in STATE['collection']: STATE['collection'].append(eid)
    STATE['history'].insert(0,{'life':STATE['life'],'name':STATE['name'],
                               'age':STATE['age'],'year':STATE['year'],
                               'ending':ENDINGS_BY_ID[eid][1],'reason':reason})
    STATE['history']=STATE['history'][:50]
    STATE['event_id']=None
    STATE['stage']='ending'
    STATE['outcome']=None
    mark_checkpoint('第 '+str(STATE['life'])+' 世・本世結局')


def choice(direction):
    if STATE['stage']!='card': raise ValueError('請先觀看目前的選擇結果。')
    e=get_current_event()
    if not e: raise ValueError('找不到當前事件。')
    opt=e['choices'][0 if direction=='left' else 1]
    for k,v in opt['effects'].items():
        if k in STAT_KEYS:
            lo=-100 if k=='karma' else 0
            STATE['stats'][k]=max(lo,min(100,STATE['stats'][k]+v))
        else:
            STATE['favor'][k]=STATE['favor'].get(k,0)+v
    STATE['flags'].update(opt['flags'])
    if e['id'] not in STATE['life_seen']: STATE['life_seen'].append(e['id'])
    if e.get('once') and e['id'] not in STATE['global_seen']: STATE['global_seen'].append(e['id'])
    event_lines=EVENT_DIALOGUES.get(e['id'],{}).get(direction,[])
    STATE['outcome']={'direction':direction,'label':opt['label'],'text':opt['result'],
                      'effects':opt['effects'],'instant_death':False,
                      'dialogues':[{'speaker':who,'text':line} for who,line in event_lines]}
    STATE['event_num']+=1
    if opt['die'] or STATE['stats']['health']<=0:
        STATE['outcome']['instant_death']=True
        STATE['outcome']['death_text']='這個選擇結束了你此世的人生。'
        STATE['death_reason']='以命下注' if opt['die'] else '健康耗盡'
    STATE['stage']='result'
    STATE['checkpoint_ready']=False
    STATE['checkpoint_label']=''
    save()
    return public_state()


def next_card():
    if STATE['stage']!='result': raise ValueError('目前沒有待確認的結果。')
    if STATE['outcome']['instant_death']:
        die(STATE.get('death_reason') or '意外死亡')
    else:
        eid=STATE.get('event_id') or ''
        if eid == 'intro_1':
            STATE['event_id']='intro_2'
            STATE['stage']='card'
            STATE['outcome']=None
            mark_checkpoint('第一世・神明引路（二）')
            save(); return public_state()
        if eid == 'intro_2':
            STATE['event_id']='intro_3'
            STATE['stage']='card'
            STATE['outcome']=None
            mark_checkpoint('第一世・神明引路（三）')
            save(); return public_state()
        if eid == 'intro_3':
            STATE['event_id']='intro_4'
            STATE['stage']='card'
            STATE['outcome']=None
            mark_checkpoint('第一世・神明引路（四）')
            save(); return public_state()
        if not eid.startswith('intro_') and not eid.startswith('rebirth_intro_'):
            STATE['age']+=2
            STATE['year']=STATE['birth_year']+STATE['age']
        if STATE['year']>=3026:
            STATE['year']=3026
            die('時間抵達西元 3026 年')
        elif STATE['age']>=100:
            die('百歲高齡，壽終正寢')
        elif STATE['age']>=60 and random.random() < min(.83,.028+(STATE['age']-60)*.014):
            die('年老後安詳離世')
        else:
            e=choose_event()
            STATE['event_id']=e['id']
            STATE['stage']='card'
            STATE['outcome']=None
            if e.get('once') or e['who'] in ('yu','mao','elder','traveler','other') or STATE['event_num'] % 8 == 0 or eid.startswith('intro_') or eid.startswith('rebirth_intro_'):
                mark_checkpoint('第 '+str(STATE['life'])+' 世・'+e['title'])
            else:
                STATE['checkpoint_ready']=False
                STATE['checkpoint_label']=''
    save()
    return public_state()


def rebirth(name):
    if STATE['stage']!='ending': raise ValueError('尚未進入本世結局。')
    if STATE['final']: raise ValueError('世界已抵達 3026 年，可建立新遊戲。')
    year=STATE['year']+19  # 死亡後一年出生，十八歲時再次開始滑卡。
    if year>3026:
        STATE['year']=3026
        STATE['final']=True
        save()
        return public_state()
    STATE['life']+=1
    STATE['birth_year']=STATE['year']+1
    STATE['age']=18
    STATE['year']=year
    STATE['name']=(name or '').strip()[:18] or ('無名之人'+str(STATE['life']))
    STATE['stats']=DEFAULT_STATS.copy()
    STATE['life_seen']=[]
    STATE['event_num']=0
    STATE['event_id']='rebirth_intro_'+str(STATE['life'])
    STATE['stage']='card'
    STATE['outcome']=None
    STATE['death_reason']=''
    STATE['last_ending']=None
    mark_checkpoint('第 '+str(STATE['life'])+' 世・重生的起點')
    save()
    return public_state()


class Handler(BaseHTTPRequestHandler):
    def send_data(self, code, data):
        body=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path=unquote(urlsplit(self.path).path)
        if path=='/api/state':
            with LOCK: self.send_data(200,public_state())
            return
        if path=='/' or path=='/index.html': p=BASE/'web'/'index.html'
        elif path.startswith('/assets/'):
            p=BASE/'assets'/path.removeprefix('/assets/')
            if p.parent.resolve()!=(BASE/'assets').resolve(): self.send_error(403);return
        else: self.send_error(404,'沒有這個頁面');return
        if not p.exists() or not p.is_file(): self.send_error(404,'找不到角色圖片');return
        body=p.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type',mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','public, max-age=86400' if '/assets/' in path else 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        global STATE
        try:
            count=int(self.headers.get('Content-Length','0'))
            if count>65536: raise ValueError('資料過大。')
            payload=json.loads(self.rfile.read(count) or b'{}')
            with LOCK:
                if self.path=='/api/new':
                    name=str(payload.get('name',''))
                    gender=payload.get('gender')
                    if gender not in ('male','female'): raise ValueError('請選擇男性或女性。')
                    if not name.strip(): raise ValueError('請填寫玩家姓名。')
                    res=new_game(name,gender,bool(payload.get('keep_collection',True)))
                elif self.path=='/api/load-slot':
                    res=load_slot(payload.get('slot'))
                else:
                    if not STATE: raise ValueError('請先建立遊戲。')
                    if self.path=='/api/choice':
                        direction=payload.get('direction')
                        if direction not in ('left','right'): raise ValueError('選項無效。')
                        res=choice(direction)
                    elif self.path=='/api/next': res=next_card()
                    elif self.path=='/api/rebirth': res=rebirth(str(payload.get('name','')))
                    elif self.path=='/api/save-slot':
                        res=save_slot(payload.get('slot'))
                    elif self.path=='/api/tutorial-complete':
                        STATE['tutorial_seen']=True
                        save();res=public_state()
                    elif self.path=='/api/effects':
                        STATE['effects_sound']=bool(payload.get('enabled'))
                        save();res=public_state()
                    elif self.path=='/api/sound':
                        STATE['sound']=bool(payload.get('sound'))
                        save();res=public_state()
                    else: self.send_error(404);return
            self.send_data(200,res)
        except (ValueError,TypeError,KeyError) as exc:
            self.send_data(400,{'error':str(exc)})
        except Exception as exc:
            print('伺服器錯誤:',repr(exc),file=sys.stderr)
            self.send_data(500,{'error':'伺服器發生錯誤，請重新整理。'})

    def log_message(self, format, *args):
        if not str(args[1] if len(args)>1 else '').startswith('200'):
            super().log_message(format,*args)


def main():
    global STATE
    parser=argparse.ArgumentParser(description='無名輪迴 Python 人物滑卡版')
    parser.add_argument('--port',type=int,default=8765,help='預設埠號 8765')
    parser.add_argument('--host',default='0.0.0.0',help='預設開放區域網路連線')
    parser.add_argument('--no-browser',action='store_true',help='不要自動開瀏覽器')
    args=parser.parse_args()
    STATE=read_save()
    sync_legacy_codex()
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    url='http://127.0.0.1:'+str(args.port)
    print('\n《無名輪迴》啟動成功！')
    print('在本機瀏覽器開啟：',url)
    print('手機需與電腦在同一 Wi-Fi，並使用電腦區域網路 IP。')
    print('存檔位置：',SAVE)
    print('按 Ctrl+C 停止遊戲伺服器。\n')
    if not args.no_browser: threading.Timer(0.5,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: print('\n遊戲已停止。')
    finally: server.server_close()

if __name__=='__main__': main()
