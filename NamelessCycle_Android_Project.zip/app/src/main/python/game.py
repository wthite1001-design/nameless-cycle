#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""無名輪迴：只需 Python 3.9+，無須 pip 安裝套件。
執行 python game.py；瀏覽器進入 http://127.0.0.1:8765
可用 python game.py --port 8766 --no-browser 修改埠號/關閉自動開啟。
"""
import argparse
from copy import deepcopy
import json
import mimetypes
import os
from pathlib import Path
import random
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit
from story import CHARACTERS, EVENTS, ENDINGS

BASE = Path(os.environ.get('NML_BASE_DIR') or Path(__file__).resolve().parent)
SAVE = BASE / 'data' / 'save.json'
SAVE.parent.mkdir(parents=True, exist_ok=True)
ENDINGS_BY_ID = {x[0]: x for x in ENDINGS}
EVENTS_BY_ID = {e['id']: e for e in EVENTS}
STATE = None
LOCK = threading.RLock()
# 三個獨立的手動節點存檔，不會被平常的自動續玩覆蓋。
SLOT_COUNT = 3


def slots_file():
    return SAVE.with_name('checkpoints.json')


def read_slots():
    try:
        raw = json.loads(slots_file().read_text(encoding='utf-8'))
        return raw if isinstance(raw, dict) else {}
    except (OSError, ValueError):
        return {}


def slots_summary():
    raw = read_slots()
    result = []
    for num in range(1, SLOT_COUNT + 1):
        item = raw.get(str(num))
        if isinstance(item, dict) and isinstance(item.get('state'), dict):
            s = item['state']
            result.append({'slot': num, 'occupied': True,
                           'name': s.get('name','無名之人'), 'gender': s.get('gender','female'),
                           'life': s.get('life',1), 'year': s.get('year',2026), 'age': s.get('age',18),
                           'label': item.get('label','重要節點'), 'saved_at': item.get('saved_at','')})
        else:
            result.append({'slot': num, 'occupied': False})
    return result


def validate_slot(num):
    if type(num) is not int or not 1 <= num <= SLOT_COUNT:
        raise ValueError('存檔欄位必須是 1～3。')
    return num


def mark_checkpoint(label):
    STATE['checkpoint_ready'] = True
    STATE['checkpoint_label'] = label


def save_slot(num):
    num = validate_slot(num)
    if not STATE or not STATE.get('checkpoint_ready') or STATE.get('stage') not in ('card','ending'):
        raise ValueError('只有抵達重要節點或本世結局時，才能進行手動存檔。')
    data = read_slots()
    data[str(num)] = {'label': STATE.get('checkpoint_label','重要節點'),
                      'saved_at': time.strftime('%Y-%m-%d %H:%M'),
                      'state': deepcopy(STATE)}
    dest = slots_file()
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(dest)
    return public_state()


def load_slot(num):
    global STATE
    num = validate_slot(num)
    entry = read_slots().get(str(num))
    if not isinstance(entry,dict) or not isinstance(entry.get('state'),dict):
        raise ValueError('這個欄位沒有存檔。')
    existing_collection = list(STATE.get('collection',[])) if STATE else []
    existing_sound = STATE.get('sound',False) if STATE else False
    existing_fx = STATE.get('effects_sound',True) if STATE else True
    STATE = deepcopy(entry['state'])
    STATE['collection'] = list(dict.fromkeys(existing_collection + STATE.get('collection',[])))
    STATE['sound'] = existing_sound
    STATE['effects_sound'] = existing_fx
    STATE.setdefault('checkpoint_ready',False)
    STATE.setdefault('checkpoint_label','')
    save()
    return public_state()

STAT_KEYS = ('health', 'wealth', 'bonds', 'karma', 'truth')
DEFAULT_STATS = {'health': 80, 'wealth': 45, 'bonds': 45, 'karma': 0, 'truth': 0}


def read_save():
    try:
        return json.loads(SAVE.read_text(encoding='utf-8')) if SAVE.exists() else None
    except (OSError, ValueError):
        return None


def save():
    SAVE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SAVE.with_suffix('.tmp')
    tmp.write_text(json.dumps(STATE, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(SAVE)


def deity_id():
    return 'yu' if STATE['gender'] == 'female' else 'mao'


def card_data(e):
    who = deity_id() if e['who'] == 'god' else e['who']
    name, img = CHARACTERS[who]
    return {'id': e['id'], 'who': who, 'name': name, 'image': '/assets/'+img,
            'title': e['title'], 'story': e['story'],
            'left': e['choices'][0]['label'], 'right': e['choices'][1]['label']}


def intro_event():
    if deity_id() == 'yu':
        story = '月光般的世界裡，余魚朝妳伸出手：「妳醒了。從這一世開始，命運交由妳自己選擇。即使妳忘記過去，我也會記住妳。」'
        left, right = '詢問這是哪裡', '握住他的手'
        lres, rres = '余魚告訴妳，這是一段新人生的起點。', '他握緊妳的手，陪妳走向第一世。'
    else:
        story = '紫白色的光芒裡，懋貓向你伸出手：「你的人生，從現在才真正開始。每一次選擇都會留下痕跡，要好好珍惜喔。」'
        left, right = '請她解釋規則', '握住她的手'
        lres, rres = '懋貓輕聲告訴你，人生會因自己的選擇而改變。', '她笑了，帶你走向屬於自己的第一世。'
    return {'id':'intro','who':'god','title':'輪迴的起點','story':story,
            'choices':[{'label':left,'result':lres,'effects':{'truth':2},'flags':{},'die':False},
                       {'label':right,'result':rres,'effects':{'god':3,'bonds':2},'flags':{},'die':False}]}


def rebirth_event():
    n=STATE['life']
    if deity_id() == 'yu':
        text = '余魚把上一世的名字寫進光裡：「這是妳的第 '+str(n)+' 世。即使世界變了，我依然在這裡。」'
        l,r='問他前世的事','謝謝他一直等待'
        lr,rr='他告訴妳一部分曾經發生的事。','他的目光柔和了些：「去吧，這一世也要好好活著。」'
    else:
        text = '懋貓在輪迴長廊等著你：「第 '+str(n)+' 世了。這次，又想成為什麼樣的人呢？」'
        l,r='問她記不記得','與她約定再見'
        lr,rr='她點頭：「我記得，所有的名字我都留著。」','懋貓輕輕握住你的手：「我會在這裡等你。」'
    return {'id':'rebirth_intro_'+str(n),'who':'god','title':'再一次醒來','story':text,
            'choices':[{'label':l,'result':lr,'effects':{'truth':3,'god':2},'flags':{},'die':False},
                       {'label':r,'result':rr,'effects':{'bonds':3,'god':3},'flags':{},'die':False}]}


def get_current_event():
    eid = STATE.get('event_id')
    if eid == 'intro': return intro_event()
    if eid and eid.startswith('rebirth_intro_'): return rebirth_event()
    e = EVENTS_BY_ID.get(eid)
    if e is None and eid and eid.startswith('interlude_'):
        # 跨程式重啟後，仍能恢復長壽周目臨時產生的事件。
        from story import EXTRA, E, C
        try:
            index = int(eid.rsplit('_',1)[1]) % len(EXTRA)
            who,title,story,ln,lr,rn,rr,le,re = EXTRA[index]
            e = E(eid,who,title,story,C(ln,lr,le),C(rn,rr,re))
            EVENTS_BY_ID[eid] = e
        except (ValueError,IndexError):
            pass
    return e


def can_offer(e):
    if e['id'] in STATE['life_seen']: return False
    if e['once'] and e['id'] in STATE['global_seen']: return False
    if e['min_life'] > STATE['life'] or e['min_year'] > STATE['year']: return False
    if not(e['min_age'] <= STATE['age'] <= e['max_age']): return False
    for k, needed in e['require'].items():
        if STATE['flags'].get(k) != needed: return False
    if e['who'] in ('yu','mao') and e['who'] != deity_id(): return False
    return True


def choose_event():
    eligible = [e for e in EVENTS if can_offer(e)]
    if not eligible:
        # 少數長壽周目用新的生活事件替補，仍保留對應角色與各自不同的文本。
        from story import EXTRA, E, C
        slot = STATE['event_num'] % len(EXTRA)
        who,title,story,ln,lr,rn,rr,le,re=EXTRA[slot]
        e=E('interlude_'+str(STATE['life'])+'_'+str(STATE['event_num']),who,title,
            story,C(ln,lr,le),C(rn,rr,re))
        EVENTS_BY_ID[e['id']]=e
        return e
    weights=[]
    for e in eligible:
        w=e.get('weight',1)
        if e['who'] in ('yu','mao') and STATE['life']>1: w+=1
        if e['who'] in STATE.get('favor',{}) and STATE['favor'][e['who']] >= 3: w+=1
        weights.append(w)
    return random.choices(eligible,weights=weights,k=1)[0]


def public_state():
    if not STATE: return {'started':False,'endings_total':len(ENDINGS),'slots':slots_summary()}
    result = {k:STATE[k] for k in ('name','gender','life','age','year','stats','event_num','stage','sound','history','last_ending','final')}
    result.update({'started':True,'god':CHARACTERS[deity_id()][0],
                   'god_image':'/assets/'+CHARACTERS[deity_id()][1],
                   'collection':[{'id':k,'title':ENDINGS_BY_ID[k][1],'description':ENDINGS_BY_ID[k][2]}
                                  for k in STATE['collection'] if k in ENDINGS_BY_ID],
                   'endings_total':len(ENDINGS),'favor':STATE['favor'],
                   'effects_sound':STATE.get('effects_sound',True),
                   'checkpoint_ready':STATE.get('checkpoint_ready',False),
                   'checkpoint_label':STATE.get('checkpoint_label',''),
                   'slots':slots_summary()})
    if STATE['stage'] in ('card','result'):
        e=get_current_event()
        result['card']=card_data(e) if e else None
    if STATE['stage']=='result': result['outcome']=STATE.get('outcome')
    if STATE['stage']=='ending':
        e=ENDINGS_BY_ID.get(STATE.get('last_ending','quiet_life'),ENDINGS_BY_ID['quiet_life'])
        result['ending']={'id':e[0],'title':e[1],'description':e[2],'reason':STATE.get('death_reason','')}
    return result


def new_game(name, gender, keep_collection=True):
    global STATE
    prev = STATE or {}
    STATE = {'name':name[:18].strip() or '無名之人','gender':gender,'life':1,
             'birth_year':2008,'age':18,'year':2026,
             'stats':DEFAULT_STATS.copy(),'favor':{'god':0},'flags':{},
             'life_seen':[],'global_seen':[],'event_id':'intro','event_num':0,
             'stage':'card','outcome':None,'death_reason':'','last_ending':None,
             'collection':list(prev.get('collection',[])) if keep_collection else [],
             'history':[],'final':False,'sound':prev.get('sound',True),
             'effects_sound':prev.get('effects_sound',True),
             'checkpoint_ready':True,'checkpoint_label':'第一世・輪迴的起點'}
    save()
    return public_state()


def settle_ending():
    s=STATE['stats']; f=STATE['flags']; v=STATE['favor']
    special=[
        ('last_rebirth',STATE['final']),
        ('god_love', f.get('god_date') and f.get('god_promise') and v.get('god',0)>=12),
        ('god_guard',v.get('god',0)>=20),
        ('other_together',f.get('dual_destiny') or f.get('shared_exit')),
        ('other_alone',f.get('single_exit')),
        ('beyond_rebirth',f.get('beyond_cycle') and s['truth']>=65),
        ('child_elder',f.get('child_elder_truth')),
        ('elder_memory',f.get('elder_book') and f.get('elder_letter')),
        ('boy_reunion',f.get('boy_reunion') and v.get('boy',0)>=6),
        ('girl_wish',f.get('girl_wish') and f.get('girl_flower')),
        ('friend_home',f.get('ordinary_life') or f.get('friend_confession') and v.get('friend',0)>=6),
        ('detective_truth',f.get('case_solved') and s['truth']>=35),
        ('reporter_truth',f.get('truth_public')),
        ('science_cycle',f.get('artificial_cycle')),
        ('rival_peace',f.get('rival_allied') or f.get('rival_peace') and v.get('rival',0)>5),
        ('rival_duel',f.get('rival_duel') and v.get('rival',0)<0),
        ('guard_oath',f.get('guard_saved')),
        ('mercenary_bond',f.get('mercenary_bond') or f.get('mercenary_loyal')),
        ('dealer_fate',f.get('dealer_life') or f.get('dealer_secret')),
        ('traveler_road',f.get('first_name') or f.get('secret_map')),
        ('child_legacy',f.get('child_helped') and s['karma']>=35),
        ('names_record',f.get('inherited_notes') or f.get('first_name')),
        ('lost_memories',f.get('lost_memory')),
        ('broken_promise',f.get('unopened_letter')),
        ('future_record',f.get('memory_archive') or f.get('parallel_records')),
        ('promise_guarded',f.get('witness_token') and not f.get('truth_public')),
        ('world_change',s['karma']>=65 and s['truth']>=40),
        ('healer_way',s['karma']>=40 and f.get('patient_saved')),
        ('wealth_life',s['wealth']>=85),
        ('kind_life',s['karma']>=48),
        ('lonely_life',s['bonds']<=13),
        ('short_life',STATE['age']<40),
        ('long_life',STATE['age']>=90),
        ('quiet_life',s['health']>=55 and s['bonds']>=55),
    ]
    for eid,ok in special:
        if ok: return eid
    # 其他人生依主要傾向分流，使所有結局能被不同選擇解鎖。
    if s['wealth']>=65: return 'wealth_life'
    if s['truth']>=55: return 'names_record'
    if s['bonds']>=50: return 'quiet_life'
    if s['health']<30: return 'short_life'
    return 'distant_star'


def die(reason):
    STATE['death_reason']=reason
    STATE['final']=STATE['year']>=3026
    eid=settle_ending()
    STATE['last_ending']=eid
    if eid not in STATE['collection']: STATE['collection'].append(eid)
    STATE['history'].insert(0,{'life':STATE['life'],'name':STATE['name'],
                               'age':STATE['age'],'year':STATE['year'],
                               'ending':ENDINGS_BY_ID[eid][1],'reason':reason})
    STATE['history']=STATE['history'][:50]
    STATE['event_id']=None
    STATE['stage']='ending'
    STATE['outcome']=None
    mark_checkpoint('第 '+str(STATE['life'])+' 世・本世結局')


def choice(direction):
    if STATE['stage']!='card': raise ValueError('請先觀看目前的選擇結果。')
    e=get_current_event()
    if not e: raise ValueError('找不到當前事件。')
    opt=e['choices'][0 if direction=='left' else 1]
    for k,v in opt['effects'].items():
        if k in STAT_KEYS:
            lo=-100 if k=='karma' else 0
            STATE['stats'][k]=max(lo,min(100,STATE['stats'][k]+v))
        else:
            STATE['favor'][k]=STATE['favor'].get(k,0)+v
    STATE['flags'].update(opt['flags'])
    if e['id'] not in STATE['life_seen']: STATE['life_seen'].append(e['id'])
    if e.get('once') and e['id'] not in STATE['global_seen']: STATE['global_seen'].append(e['id'])
    STATE['outcome']={'direction':direction,'label':opt['label'],'text':opt['result'],
                      'effects':opt['effects'],'instant_death':False}
    STATE['event_num']+=1
    if opt['die'] or STATE['stats']['health']<=0:
        STATE['outcome']['instant_death']=True
        STATE['outcome']['death_text']='這個選擇結束了你此世的人生。'
        STATE['death_reason']='以命下注' if opt['die'] else '健康耗盡'
    STATE['stage']='result'
    STATE['checkpoint_ready']=False
    STATE['checkpoint_label']=''
    save()
    return public_state()


def next_card():
    if STATE['stage']!='result': raise ValueError('目前沒有待確認的結果。')
    if STATE['outcome']['instant_death']:
        die(STATE.get('death_reason') or '意外死亡')
    else:
        eid=STATE.get('event_id')
        if eid!='intro' and not (eid or '').startswith('rebirth_intro_'):
            STATE['age']+=2
            STATE['year']=STATE['birth_year']+STATE['age']
        if STATE['year']>=3026:
            STATE['year']=3026
            die('時間抵達西元 3026 年')
        elif STATE['age']>=100:
            die('百歲高齡，壽終正寢')
        elif STATE['age']>=60 and random.random() < min(.83,.028+(STATE['age']-60)*.014):
            die('年老後安詳離世')
        else:
            e=choose_event()
            STATE['event_id']=e['id']
            STATE['stage']='card'
            STATE['outcome']=None
            if e.get('once') or e['who'] in ('yu','mao','elder','traveler','other') or STATE['event_num'] % 8 == 0:
                mark_checkpoint('第 '+str(STATE['life'])+' 世・'+e['title'])
            else:
                STATE['checkpoint_ready']=False
                STATE['checkpoint_label']=''
    save()
    return public_state()


def rebirth(name):
    if STATE['stage']!='ending': raise ValueError('尚未進入本世結局。')
    if STATE['final']: raise ValueError('世界已抵達 3026 年，可建立新遊戲。')
    year=STATE['year']+19  # 死亡後一年出生，十八歲時再次開始滑卡。
    if year>3026:
        STATE['year']=3026
        STATE['final']=True
        save()
        return public_state()
    STATE['life']+=1
    STATE['birth_year']=STATE['year']+1
    STATE['age']=18
    STATE['year']=year
    STATE['name']=(name or '').strip()[:18] or ('無名之人'+str(STATE['life']))
    STATE['stats']=DEFAULT_STATS.copy()
    STATE['life_seen']=[]
    STATE['event_num']=0
    STATE['event_id']='rebirth_intro_'+str(STATE['life'])
    STATE['stage']='card'
    STATE['outcome']=None
    STATE['death_reason']=''
    STATE['last_ending']=None
    mark_checkpoint('第 '+str(STATE['life'])+' 世・重生的起點')
    save()
    return public_state()


class Handler(BaseHTTPRequestHandler):
    def send_data(self, code, data):
        body=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path=unquote(urlsplit(self.path).path)
        if path=='/api/state':
            with LOCK: self.send_data(200,public_state())
            return
        if path=='/' or path=='/index.html': p=BASE/'web'/'index.html'
        elif path.startswith('/assets/'):
            p=BASE/'assets'/path.removeprefix('/assets/')
            if p.parent.resolve()!=(BASE/'assets').resolve(): self.send_error(403);return
        else: self.send_error(404,'沒有這個頁面');return
        if not p.exists() or not p.is_file(): self.send_error(404,'找不到角色圖片');return
        body=p.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type',mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','public, max-age=86400' if '/assets/' in path else 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        global STATE
        try:
            count=int(self.headers.get('Content-Length','0'))
            if count>65536: raise ValueError('資料過大。')
            payload=json.loads(self.rfile.read(count) or b'{}')
            with LOCK:
                if self.path=='/api/new':
                    name=str(payload.get('name',''))
                    gender=payload.get('gender')
                    if gender not in ('male','female'): raise ValueError('請選擇男性或女性。')
                    if not name.strip(): raise ValueError('請填寫玩家姓名。')
                    res=new_game(name,gender,bool(payload.get('keep_collection',True)))
                elif self.path=='/api/load-slot':
                    res=load_slot(payload.get('slot'))
                else:
                    if not STATE: raise ValueError('請先建立遊戲。')
                    if self.path=='/api/choice':
                        direction=payload.get('direction')
                        if direction not in ('left','right'): raise ValueError('選項無效。')
                        res=choice(direction)
                    elif self.path=='/api/next': res=next_card()
                    elif self.path=='/api/rebirth': res=rebirth(str(payload.get('name','')))
                    elif self.path=='/api/save-slot':
                        res=save_slot(payload.get('slot'))
                    elif self.path=='/api/effects':
                        STATE['effects_sound']=bool(payload.get('enabled'))
                        save();res=public_state()
                    elif self.path=='/api/sound':
                        STATE['sound']=bool(payload.get('sound'))
                        save();res=public_state()
                    else: self.send_error(404);return
            self.send_data(200,res)
        except (ValueError,TypeError,KeyError) as exc:
            self.send_data(400,{'error':str(exc)})
        except Exception as exc:
            print('伺服器錯誤:',repr(exc),file=sys.stderr)
            self.send_data(500,{'error':'伺服器發生錯誤，請重新整理。'})

    def log_message(self, format, *args):
        if not str(args[1] if len(args)>1 else '').startswith('200'):
            super().log_message(format,*args)


def main():
    global STATE
    parser=argparse.ArgumentParser(description='無名輪迴 Python 人物滑卡版')
    parser.add_argument('--port',type=int,default=8765,help='預設埠號 8765')
    parser.add_argument('--host',default='0.0.0.0',help='預設開放區域網路連線')
    parser.add_argument('--no-browser',action='store_true',help='不要自動開瀏覽器')
    args=parser.parse_args()
    STATE=read_save()
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    url='http://127.0.0.1:'+str(args.port)
    print('\n《無名輪迴》啟動成功！')
    print('在本機瀏覽器開啟：',url)
    print('手機需與電腦在同一 Wi-Fi，並使用電腦區域網路 IP。')
    print('存檔位置：',SAVE)
    print('按 Ctrl+C 停止遊戲伺服器。\n')
    if not args.no_browser: threading.Timer(0.5,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: print('\n遊戲已停止。')
    finally: server.server_close()

if __name__=='__main__': main()
